﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace DigiOPS.TechFoundation.Collaboration
{
    [Serializable]
    public class EMailInfo : CollaborationInfo
    {       
            /// <summary>
            /// Mail tracker unique id
            /// </summary>
            public int iMailTrackerId { get; set; }

            /// <summary>
            /// Flag to identify the mail sent/ not sent
            /// </summary>
            public Boolean bMailSent { get; set; }

            /// <summary>
            /// Folder path of mail template
            /// </summary>
            public string szPath { get; set; }

            /// <summary>
            /// Port to send mails
            /// </summary>
            public string szPort { get; set; }

            /// <summary>
            /// Host to send mails
            /// </summary>
            public string szHost { get; set; }
            /// <summary>
            /// Recipient to send mails
            /// </summary>
            public string Recipient { get; set; }
            /// <summary>
            /// Sender to send mails
            /// </summary>
            public string Sender { get; set; }
            /// <summary>
            /// List of senders to send mails
            /// </summary>
            public string szSentTo { get; set; }
            /// <summary>
            /// List of senders to send mails
            /// </summary>
            public string szSentCC { get; set; }
            /// <summary>
            /// From mail address
            /// </summary>
            public string szSentFrom { get; set; }
            /// <summary>
            /// Subject of mail
            /// </summary>
            public string szSentSubj { get; set; }
            /// <summary>
            /// Mail name
            /// </summary>
            public string szMailName { get; set; }
            /// <summary>
            /// Mail body content
            /// </summary>
            public string szMailBody { get; set; }
            /// <summary>
            /// Mail body template - file name
            /// </summary>
            public string szMailBodyFileName { get; set; }
            /// <summary>
            /// Type of mail name
            /// </summary>
            public string szMailTypeName { get; set; }
            /// <summary>
            /// Type of mail priority
            /// </summary>
            public string szMailPriority { get; set; }
            /// <summary>
            /// Mail template type
            /// </summary>
            public string szMailTemplateType { get; set; }

            /// <summary>
            /// Flag to set , if body contains any image to be embed
            /// </summary>
            public Boolean IsBodyWithEmbededObjects { get; set; }
            /// <summary>
            /// Flag to set , if body should replace text with give replace content
            /// </summary>
            public Boolean IsBodyWithReplaceChar { get; set; }
            /// <summary>
            /// Flag to indicate, going to send the mail body as Plain Text
            /// </summary>
            public Boolean IsBodyPlainText { get; set; }

           
            /// <summary>
            /// To recipient List
            /// </summary>
            public List<MailAddressInfo> MailAddressList { get; set; }
            /// <summary>
            /// If IsBodyWithEmbededObjects is set as true, then consumer should pass Embeded Objects as EntityList
            /// </summary>
            public List<EmbededObjectsInfo> EmbededObjectsList { get; set; }
            /// <summary>
            /// If IsBodyWithReplaceChar is set as true, then consumer should pass replace mailcontent as EntityList
            /// </summary>
            public List<MailMergeContentInfo> MailMergeContentList { get; set; }
            public List<ToAddressInfo> ToAddressList { get; set; }
            public List<CCAddressInfo> CCAddressList { get; set; }
        }

        /// <summary>
        /// Added for mail Trigger Component - By setting this values, User can embeded image in mail content
        /// </summary>
        [Serializable]
        public class EmbededObjectsInfo
        {
            public string szPATH { get; set; }
            public string szName { get; set; }
        }

        /// <summary>
        /// Added for mail Trigger Component - The mail content will be replaced by values
        /// </summary>
        [Serializable]
        public class MailMergeContentInfo
        {
            public string szReplaceName { get; set; }
            public string szReplaceValue { get; set; }
        }

        /// <summary>
        /// SendMailCCRecipient
        /// </summary>
        /// 
        [Serializable]
        public class ToAddressInfo
        {
            public string ToAddress { get; set; }
        }
        [Serializable]
        public class CCAddressInfo
        {
            public string CCAddress { get; set; }
        }

        [Serializable]
        public class MailAddressInfo
        {
            public string FromAddress { get; set; }
            public string ToAddress { get; set; }
            public string CCAddress { get; set; }
        }

       

        /// <summary>
        /// BaseTransportEntity class
        /// </summary>
        [Serializable]
        public class BaseTransportEntity //: entityXMLSerialization
        {
            public string SessionId { get; set; }
            public int Id { get; set; }
            public int CurrentUserID { get; set; }
            public int CurrentUserRoleID { get; set; }
            public int _ProgramID { get; set; }
            public int _ProcessID { get; set; }
            public int _SubProcessID { get; set; }
            public string ViewName { get; set; }
            public string EntityName { get; set; }
            public string eventAction { get; set; }
            public string _ProcessedDate { get; set; }
            public string _ProcessedFromDate { get; set; }
            public string _ProcessedToDate { get; set; }
            public string _ReceivedDate { get; set; }
            public int iSubCategoryId { get; set; }
            public string ExtAuditTypeName { get; set; }
            public int _StartRowIndex { get; set; }
            public int _MaximumRows { get; set; }
            public string _SortOrder { get; set; }
            public string _SortColumn { get; set; }
            public int? _TotalRows { get; set; }
            public string ReturnValue { get; set; }
            public bool bIsEmpNeeded { get; set; }
            public bool bIsLineNeeded { get; set; }
            public bool bIsLineApplicable { get; set; }
            public bool IsPeerCheckerReq { get; set; }
            public bool bIsSLAActivityApplicable { get; set; }
            public bool IsReadonDDL { get; set; }
            public bool isBusiAutoAllocationSamplingRequired { get; set; }
            public bool isExternalAutoAllocationSamplingRequired { get; set; }
            public int _ElementCount { get; set; }
            public string NoofLineReuired { get; set; }


            public bool bIsExternalAudit { get; set; }
            public int ReportID { get; set; }
            public int RatingDifferenceCount { get; set; }
        }
    }
    

