﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    /// <summary>
    /// Interface to handle cryptography
    /// </summary>
    public interface ICrypt
    {
        string Encrypt(CryptInfo objCryptInfo);
        string Decrypt(CryptInfo objCryptInfo);

    }

}
