﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;

namespace DigiOPS.TechFoundation.Security
{
    public class BaseUserSecurity : IUserSecurity
    {                 
            //ILoggingFactory objLogging = new LoggingFactory();
            //objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
         
        protected ResponseInfo ValidateUserContext(UserContextInfo objUserContextInfo)
	{     
            
        
        ResponseInfo objResponseInfo = new ResponseInfo { ResultStatus = false };
        if (string.IsNullOrEmpty(objUserContextInfo.UserID.Trim()))
        {          
            objUserContextInfo.ErrorMessage.Append(ErrorMessage.ERR_REQ_Username);
            
            return objResponseInfo;
        }
        if (string.IsNullOrEmpty(objUserContextInfo.Password.Trim()))
        {
           
            objUserContextInfo.ErrorMessage.Append(ErrorMessage.ERR_REQ_Password);
            return objResponseInfo;
        }
        if (string.IsNullOrEmpty(objUserContextInfo.Domain.Trim()))
        {
            
            objUserContextInfo.ErrorMessage.Append("Domain is null or empty. ");
            return objResponseInfo;
        }

        return new ResponseInfo { ResultStatus = true };
	}

        public virtual bool Authenticate(UserContextInfo objUserContextInfo)
        {
            return false;
        }
        public virtual bool Authorize(UserRoleInfo objUserRoleInfo)
        {
            return false;
        }




        public bool UserTimeStampCheck(string jsonWebToken, string secretKey, UserContextInfo userContextInfo)
        {
            UserContextInfo objUserContextInfo = new UserContextInfo();
           
            try
            {
                byte[] secretKeyBytes = Encoding.ASCII.GetBytes(secretKey);
                string decodedToken = Jose.JWT.Decode(jsonWebToken, secretKeyBytes);
                JsonToken data = JsonConvert.DeserializeObject<JsonToken>(decodedToken);
                userContextInfo.UserID = data.UserID;
                userContextInfo.CreatedOn = data.CreatedDateTime;
                userContextInfo.ResultStatus = true;
            }
            catch (Exception ex)
            {
                userContextInfo.ErrorMessage.Append(ex.Message);
            }
            return userContextInfo.ResultStatus;
        }

        public virtual bool ForgotPassword( UserInfo objUserInfo)
        {
            
            //= new UserInfo { ResultStatus = false };
            if (string.IsNullOrEmpty(objUserInfo.EncryptConfirmPassword.Trim()))
            {
                
                objUserInfo.ErrorMessage.Append(ErrorMessage.ERR_REQ_EncryptConfirmPassword);
                return false;
            }
            if (string.IsNullOrEmpty(objUserInfo.EncryptPassword.Trim()))
            {
               
                objUserInfo.ErrorMessage.Append(ErrorMessage.ERR_REQ_EncryptPassword);
                return false;
            }
            if (objUserInfo.EncryptPassword.Trim() == objUserInfo.EncryptConfirmPassword.Trim())
            {
               
                objUserInfo.ErrorMessage.Append("Password saved successfully");
                return true;
            }

            if (objUserInfo.EncryptPassword.Trim() != objUserInfo.EncryptConfirmPassword.Trim())
            {
                
                objUserInfo.ErrorMessage.Append("Password not matching");
                return false;
            }


            return false;
        }
        public virtual bool CheckRecentPasswords(string NewPassword, UserInfo objUserInfo)
        {
           
            foreach (string objPasswordList in objUserInfo.EncryptPasswordList)
            {
                if (NewPassword.Trim() != objPasswordList.Trim())
                {
                   
                    objUserInfo.ErrorMessage.Append("Password saved successfully");
                    
                }
                else
                {
                    
                    objUserInfo.ErrorMessage.Append("Password saved successfully"); 
                    return false; }
                     
            }
            return true;
        }
        public virtual bool SingleSessionEnforcement()
        {
            return false;
        }
        public virtual void IsLogEnabled(string LogMessage,bool IsEnabled) 
        {
            LogInfo objLogInfo = new LogInfo();
            ILoggingFactory objLogging = new LoggingFactory();            
            if (IsEnabled) {
                objLogInfo.Message = LogMessage;
                objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);               
            }
        }
    }

    public class JsonToken
    {
        public string UserID { get; set; }
        public DateTime CreatedDateTime { get; set; }
    }
  
   
}
