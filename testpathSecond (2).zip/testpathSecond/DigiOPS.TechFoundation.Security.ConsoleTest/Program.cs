﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Newtonsoft.Json;
using DigiOPS.TechFoundation.Security;
using DigiOPS.TechFoundation.DataTransfer;
using System.Data;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.UserManagement;
using DigiOPS.TechFoundation.Configuration;

namespace DigiOPS.TechFoundation.Security.ConsoleTest
{
 /// <summary>
 /// 
 /// </summary>
    public class Program
    {
        public static void Main(string[] args)
        {
            DataElementEntity DataElement = new DataElementEntity();
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
           // DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "QUART";

            DataElement._SubProcessID = 3;
            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            //List<DataElementEntity> dataElements = new List<DataElementEntity>();
            List<DataElementEntity> dataElementsList = new List<DataElementEntity>();

            // ArrayList dataElements = new ArrayList();
            config.ReadConfiguration(DataElementEnt, ref dataElementsList);
            int n = dataElementsList.Count;
            Console.WriteLine(n);
            Console.ReadLine();




/*
            DataElementEntity DataElement = new DataElementEntity();//to write on quart 
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "QUART";

            DataElement._SubProcessID = 3;
            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            //List<DataElementEntity> dataElements = new List<DataElementEntity>();
            List<DataElementEntity> dataElementsList = new List<DataElementEntity>();

            // ArrayList dataElements = new ArrayList();
            config.ReadConfiguration(DataElementEnt, ref dataElementsList);
            int n = dataElementsList.Count;

            Console.WriteLine(n);
            Console.ReadLine();
*/

/*
            DataElementEntity DataElement = new DataElementEntity();//to write on EMT//change fieldmasterID,fieldname,datatypeID,fielddatatypeID
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "EMT";
            DataElement.CountryID = 4;
            DataElement.MailBoxID = 2;
            DataElement.defaultValue = "";
            DataElement.fieldname = "fieldname7";
            DataElement.FieldTypeID = "8";
            DataElement.FieldDataTypeID = "7";
            DataElement.ValidationTypeID = 1;
            DataElement.FieldMaxLength = 9;
           // DataElement.UserId = "319620";
            DataElement.chkactive = true;
            DataElement.Mandatory = true;
            DataElement.btnMap = "Configure";
            DataElement.FieldMasterId = 109;
            string value = null;

            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            config.WriteConfiguration(DataElementEnt, ref value);
            Console.WriteLine(DataElementEnt.ErrorMessage);
            Console.ReadLine();
         */   
           // ---------------------------------to read data on EMT
          /*  
            DataElementEntity DataElement = new DataElementEntity();//to Read on EMT
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "EMT";
            DataElement.CaseID = "1002";



            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            //List<DataElementEntity> dataElements = new List<DataElementEntity>();
            List<DataElementEntity> dataElementsList = new List<DataElementEntity>();

            // ArrayList dataElements = new ArrayList();
            config.ReadConfiguration(DataElementEnt, ref dataElementsList);

            Console.WriteLine("{0}", dataElementsList.Count);
            Console.ReadLine();

            */
            


            //--------------------------to write dynamicfield on EMT
           
           /*
            DataElementEntity DataElement = new DataElementEntity();//to write on EMT
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "EMT";
            DataElement.CountryID=4;
            DataElement.MailBoxID =2;
            DataElement.defaultValue="";
            DataElement.fieldname = "fieldname2";
            DataElement.FieldTypeID ="1";
            DataElement.FieldDataTypeID ="2";
            DataElement.ValidationTypeID =1;
            DataElement.FieldMaxLength =9;
            DataElement.UserId = "319630";
            DataElement.chkactive=true;
            DataElement.Mandatory=true;
            DataElement.btnMap ="Configure";
            DataElement.FieldMasterId =103;
            string value = null;

            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            config.WriteConfiguration(DataElementEnt, ref value);
            Console.WriteLine(value);
            Console.ReadLine();
            */





            //List<DataElementEntity> baseList = new List<DataElementEntity>();

/*
            
            //--------------------------to read dynamicfield on quart

            DataElementEntity DataElement = new DataElementEntity();//to write on quart 
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "QUART";

            DataElement._SubProcessID =3;
            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
           //List<DataElementEntity> dataElements = new List<DataElementEntity>();
            List<DataElementEntity> dataElementsList = new List<DataElementEntity>();

           // ArrayList dataElements = new ArrayList();
            config.ReadConfiguration(DataElementEnt, ref dataElementsList);
            foreach (var item in dataElementsList)
            {
                Console.WriteLine("{0}", item.ElementName);
            }
            Console.ReadLine();
            */
            //----------------------------to write dynamicfield on quart
            /*
            DataElementEntity DataElement = new DataElementEntity();//to write on quart 
            ConfigurationInfo DataElementEnt=new ConfigurationInfo();
            DataElementEnt=(ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "QUART";
            DataElement.ElementId=1;
            DataElement.ElementName="SNo";
            DataElement.FieldType="Transaction";
            DataElement.ElementTypeId=1;
            DataElement.DataTypeId=2;
            DataElement.splChars=null;
            DataElement.ElementLength=9;
            DataElement.CodeGroupId=null;
            DataElement.SequenceNo=1;
            DataElement.MandatoryElement=true;
            DataElement.AuditFormElement=true;
            DataElement.UniqueElement=false;
            DataElement.GridViewElement=false;
            DataElement.IsReportField=false;
            DataElement.SearchableElement=true;
            DataElement.SamplingThreshold=false;
            DataElement.IsDirectAuditLevel=false;
            DataElement.DirectAuditLevelId=0;
            DataElement.minAuditRange=null;
            DataElement.maxAuditRange=null;
            DataElement.minSamplingRange=null;
            DataElement.maxSamplingRange=null;
            DataElement.DataEntryRoleId="3";
            DataElement.createdBy="6";
            DataElement.modifiedBy="9";
            DataElementEnt._SubProcessID=3;
            DataElementEnt.eventAction="INSERT";
            DataElementEnt._ElementCount=10;
            string value=null;
            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            config.WriteConfiguration(DataElementEnt, ref value);

            
            Console.WriteLine(value);
            Console.ReadLine();
            */



















            /*UserRoleInfo objRoleInfo = new UserRoleInfo();
            UserInfo user = new UserInfo();

             user.CountryId = "10";
            objRoleInfo.User = user;
             objRoleInfo.UserRoleMapId = "1";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = 0;
            n = objUserRepository.UpdateUserRole(objRoleInfo);

            Console.WriteLine(n);
            Console.ReadLine();
            */


          /*  [TestMethod]
                public void DATAupdateRoleNegative()
                {
                    UserRoleInfo objRoleInfo = new UserRoleInfo();
                    UserInfo user = new UserInfo();

                    // user.CountryId = "4";
                    //objRoleInfo.User = user;
                    //  objRoleInfo.UserRoleMapId = "1";
                    EMTUserRepository objUserRepository = new EMTUserRepository();
                    int n = 0;
                    n = objUserRepository.UpdateUserRole(objRoleInfo);

                    Assert.IsFalse(n==1);

                }*/

           /* UserInfo objRoleInfo = new UserInfo();

            objRoleInfo.UserID = "555453";
            objRoleInfo.FirstName = "a";
            objRoleInfo.LastName = "z";
            objRoleInfo.EmailID = "az@gmail.com";
            objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
            objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
            objRoleInfo.IsActive = true;
            objRoleInfo.RoleId = 1;
            objRoleInfo.UTCTime = DateTime.Now.ToString();
            //objRoleInfo.UserManagingType="";
            BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();

            int n = BASECUSTOM.CreateUser(objRoleInfo);

            Console.WriteLine(n);
            Console.ReadLine();*/


     /*
            UserRoleInfo objRoleInfo = new UserRoleInfo();
            UserInfo user = new UserInfo();
            user.UserID = "195174";
            user.CountryId = "1";
            objRoleInfo.User = user;
            //Console.WriteLine(objRoleInfo.User.UserID);
            //Console.ReadLine();
           
         
           RoleInfo role = new RoleInfo();
           role.RoleId = 2;
           List<RoleInfo> mine = new List<RoleInfo>();
           mine.Add(role);
         //List<RoleInfo> List=new List<RoleInfo>();
           //objRoleInfo.UserRoles = new List<RoleInfo>();

           objRoleInfo.UserRoles = mine;
            //objRoleInfo.LoginId = "suji";

            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.AssignRole(objRoleInfo);
            Console.WriteLine(n);
            Console.ReadLine();*/

           /* UserRoleInfo objRoleInfo = new UserRoleInfo();
            UserInfo user = new UserInfo();
            user.UserID = "195174";
            user.CountryId = "4";
            objRoleInfo.User = user;
            //Console.WriteLine(objRoleInfo.User.UserID);
            //Console.ReadLine();


           
            //List<RoleInfo> List=new List<RoleInfo>();
            //objRoleInfo.UserRoles = new List<RoleInfo>();

            objRoleInfo.UserRoleMapId = "1";
            //objRoleInfo.LoginId = "suji";

            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.UpdateUserRole(objRoleInfo);
            Console.WriteLine(n);
            Console.ReadLine();*/

      
           /* UserRoleInfo objRoleInfo = new UserRoleInfo();
           
            objRoleInfo.UserRoleMapId = "1";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.DeleteUserRole(objRoleInfo);
            Console.WriteLine(n);
            Console.ReadLine();
            */

/*
          UserInfo objRoleInfo = new UserInfo();
            //objRoleInfo.AppID = "EMT";
           
            //objRoleInfo.RoleId = 2;
            objRoleInfo.UserID = "2222";
            objRoleInfo.FirstName = "a";
            objRoleInfo.LastName = "z";
            objRoleInfo.EmailID = "az@gmail.com";
            objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
            objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
            objRoleInfo.IsActive = true;
            objRoleInfo.RoleId =1;
            //objRoleInfo.UserManagingType="";
           
            //objRoleInfo.UTCTime = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.Create(objRoleInfo);
            
            Console.WriteLine(n);
            Console.ReadLine();
 */          
            /*
            UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.UserID = "234234234";
            objRoleInfo.FirstName = "a";
            objRoleInfo.LastName = "z";
            objRoleInfo.EmailID = "az@gmail.com";
            objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
            objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
            objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
            objRoleInfo.RoleId = 1;
            objRoleInfo.IsActive = true;
            
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.Update(objRoleInfo);
            Console.WriteLine(n);
            Console.ReadLine();*/
            /*
            //User Authentication
            UserContextInfo userContextInfo = new UserContextInfo();
            userContextInfo.UserID = "587767";
            userContextInfo.Password = "My password";
            userContextInfo.Domain = "CTS";
            var securityFactory = new SecurityFactory();
            bool isAuthenticated = securityFactory.GetUserSecurityHandler("AD").Authenticate(userContextInfo);

            bool copyOfIsAuthenticated = isAuthenticated;

            //Encryption/Decryption
            CryptInfo cryptInfo = new CryptInfo();
            cryptInfo.CryptKey = "123";
            cryptInfo.ValueToCrypt = "Cognizant";
            string encryptedValue = securityFactory.GetCryptHandler("AES").Encrypt(cryptInfo);
            cryptInfo.ValueToCrypt = encryptedValue;
            string decryptedValue = securityFactory.GetCryptHandler("AES").Decrypt(cryptInfo);

            string copyOfTheDecryptedValue = decryptedValue;

            //ParseUserToken
            var securityHandler = securityFactory.GetUserSecurityHandler("AD");
            string jsonWebToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJVc2VySUQiOiI1OTk4MzUiLCJDcmVhdGVkRGF0ZVRpbWUiOiIyLzEzLzIwMTcgNDoyNjo0NiBQTSJ9.ZRamafCH37HAWoZlPIBoQLdt_z9iuznx9vnVP1YiYtw";
            string secretKey = "YOUR_CLIENT_SECRET";
            securityHandler.UserTimeStampCheck(jsonWebToken, secretKey, userContextInfo);

            string userID = userContextInfo.UserID;
            string copyOfUserID = userID;
            DateTime createdOn = userContextInfo.CreatedOn;
            DateTime copyOfCreatedOn = createdOn;
            bool resultStatus = userContextInfo.ResultStatus;
            bool copyOfResultStatus = resultStatus;
             * */

            /*
            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.InputExcelFilePath = @"D:\Lab\POCs\Security\TestExcel.xlsx";
            dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Import(dataTransferInfo);
            string errorMessage = "";
            if (dataTransferInfo.ErrorMessage != null)
            {
                errorMessage = dataTransferInfo.ErrorMessage.ToString();
            }
            int thisManyRows = dataTransferInfo.DataTable.Rows.Count;
             * */
            /*
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("AssociateID");
            DataRow oneRow = dataTable.NewRow();
            oneRow["AssociateID"] = "454545";
            dataTable.Rows.Add(oneRow);

            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            //dataTransferInfo.ExcelExportType = "Html";
            dataTransferInfo.ExcelExportType = "OleDB";
            dataTransferInfo.DataTable = dataTable;
            //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelNew.html";
            dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
            dataTransferInfo.ExcelSheetName = "TestSheetName";
            
            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);
            
            string errorMessage = "";
            if (dataTransferInfo.ErrorMessage != null)
            {
                errorMessage = dataTransferInfo.ErrorMessage.ToString();
            }

            */
        }
    }
}
