﻿using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class BaseProductLicenseKey : IProductLicenseKey
    {

        protected ResponseInfo ValidateProductKeyInfo(LicenseInfo productKeyInfo)
        {
            LogInfo objLogInfo = new LogInfo();
            ILoggingFactory objLogging = new LoggingFactory();
            ResponseInfo responseInfo = new ResponseInfo { ResultStatus = false };
            if (string.IsNullOrEmpty(productKeyInfo.ToolPurchased.Trim()))
            {
                objLogInfo.Message = "Tool purchased is null or empty. ";
                objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
                productKeyInfo.ErrorMessage.Append("Tool purchased is null or empty. ");
                return responseInfo;
            }
            if (string.IsNullOrEmpty(productKeyInfo.DateOfPurchase.Trim()))
            {
                objLogInfo.Message = "Date of purchase is null or empty. ";
                objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
                productKeyInfo.ErrorMessage.Append("Date of purchase is null or empty. ");
                return responseInfo;
            }
            if (string.IsNullOrEmpty(productKeyInfo.Version.Trim()))
            {
                objLogInfo.Message = "Version is null or empty. ";
                objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
                productKeyInfo.ErrorMessage.Append("Version is null or empty. ");
                return responseInfo;
            }
            if (string.IsNullOrEmpty(productKeyInfo.InstanceID.Trim()))
            {
                objLogInfo.Message = "Instance ID is null or empty. ";
                objLogging.GetLoggingHandler("Log4net").LogInfo(objLogInfo);
                productKeyInfo.ErrorMessage.Append("Instance ID is null or empty. ");
                return responseInfo;
            }

            return new ResponseInfo { ResultStatus = true };
        }

        public virtual string GenerateProductKey(LicenseInfo productKeyInfo)
        {
            return string.Empty;
        }

     



        public virtual bool ValidateProductLicenseKey(string encryptedProductKey)
        {
            return false;
        }
    }
}
