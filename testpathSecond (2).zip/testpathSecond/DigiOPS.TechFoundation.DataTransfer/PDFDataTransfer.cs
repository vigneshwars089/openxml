﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
    public class PDFDataTransfer : BaseDataTransfer
    {
      public override void Import(DataTransferInfo dataTransferinfo)
      {

      }

      public override void Export(DataTransferInfo dataTransferinfo)
      {

      }
    }
}
