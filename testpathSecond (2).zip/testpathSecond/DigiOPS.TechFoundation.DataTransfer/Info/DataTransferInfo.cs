﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
    public class DataTransferInfo : BaseInfo
    {
        public DataTable DataTable { get; set; }
        public string InputExcelFilePath { get; set; }
        public string DestinationExcelFilePath { get; set; }
        public string ExcelSheetName { get; set; }
        public string ExcelExportType { get; set; }
    }
    
    public struct S_DataTransferExcelTypes
    {
        public const string Excel = "Excel";
    }

    public struct S_DataTransferPDFTypes
    {
        public const string PDF = "PDF";
    }

    public struct s_DataTransferExcelExportTypes
    {
        public const string Html = "Html";
        public const string Excel = "Excel";
    }
}
