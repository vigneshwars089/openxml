﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.ExceptionHandling
{
    public class AuditException : BaseException
    {
       
         public AuditException()
        {

        }

        /// <summary>
        /// Custom Exception Constructor with message
        /// </summary>
        /// <param name="message">string</param>
        public AuditException(string message) : base(message)
        {
            this.customMessage = message;
        }

        /// <summary>
        /// Custom Exception Constructor with message and inner exception
        /// </summary>
        /// <param name="message">string</param>
        /// <param name="inner">Exception</param>
        public AuditException(string message, Exception inner)
            : base(message, inner)
        {
            this.customMessage = message;
            this.innerException = inner;
        }
    }
}
