﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;

namespace DigiOPS.TechFoundation.DataTransfer
{
    public class ExcelDataTransfer : BaseDataTransfer
    {
        public override void Import(DataTransferInfo dataTransferinfo)
        {
            string filename = dataTransferinfo.InputExcelFilePath;
            string sheetName = dataTransferinfo.ExcelSheetName;
            dataTransferinfo.DataTable = ImportExcelToDataTable(filename, sheetName, dataTransferinfo);
        }

        private DataTable ImportExcelToDataTable(string filePath, string sheetName, DataTransferInfo dataTransferInfo)
        {
            DataTable dtResult = null;
            var pathToExcel = filePath;// @"D:\IAE\Sample.xlsx";
            var connectionString = String.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES""", pathToExcel);
            try
            {
                using (OleDbConnection oleDbConnection = new OleDbConnection(connectionString))
                {
                    oleDbConnection.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    OleDbDataAdapter oleda = new OleDbDataAdapter();
                    DataSet ds = new DataSet();
                    DataTable dt = oleDbConnection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    sheetName = sheetName + "$";//"Sheet1$";
                    cmd.Connection = oleDbConnection;
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT * FROM [" + sheetName + "]";
                    oleda = new OleDbDataAdapter(cmd);
                    oleda.Fill(ds);
                    dtResult = ds.Tables[0];
                    oleDbConnection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message);
            }
            return dtResult;
        }

        public override void Export(DataTransferInfo dataTransferinfo)
        {
            switch(dataTransferinfo.ExcelExportType.ToString())
            {
                case "Html":
                    {
                        WriteToHtmlFormatExcel(dataTransferinfo);
                        break;
                    }
                case "Excel":
                    {
                        WriteToOLEDBExcel(dataTransferinfo);
                        break;
                    }
            }
        }

        private void WriteToHtmlFormatExcel(DataTransferInfo dataTransferInfo)
        {
            string sTab = "";
            StringBuilder sbResponse = new StringBuilder();

            try
            {
                DataTable dtExcelData = dataTransferInfo.DataTable;
                string storePath = dataTransferInfo.DestinationExcelFilePath;
                string sheetName = dataTransferInfo.ExcelSheetName;
                using (StringWriter sWData = new StringWriter(sbResponse))
                {
                    using (HtmlTextWriter hTextWriter = new HtmlTextWriter(sWData))
                    {
                        if (dtExcelData != null)
                        {
                            hTextWriter.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN "">");
                            //hTextWriter.Write("<meta charset='UTF-8'>");
                            hTextWriter.Write("<meta http-equiv='Content-Type' content='text/html;charset=UTF-8'>");
                            hTextWriter.Write("<font style='font-size:10.5pt; font-family:Calibri;'>");
                            hTextWriter.Write("<BR><BR><BR>");
                            hTextWriter.Write("<Table name='" + sheetName + "' border='1' bgColor='#106A86' borderColor='#000000' cellSpacing='0' cellPadding='0' style='font-size:10.5pt; font-family:Calibri; background:#EEEEEE;'> <TR>");
                            if (dtExcelData.Rows.Count > 0)
                            {
                                sTab = "";
                                foreach (DataColumn dtColumn in dtExcelData.Columns)
                                {
                                    hTextWriter.Write("<Td bgColor='#106A86'>");
                                    hTextWriter.Write("<B>");
                                    hTextWriter.Write("<font color='#FFFFFF'>" + System.Web.HttpUtility.HtmlEncode(sTab + dtColumn.ColumnName) + "</font>");
                                    sTab = "\t";
                                    hTextWriter.Write("</B>");
                                    hTextWriter.Write("</Td>");
                                }

                                hTextWriter.Write("</TR>");

                                foreach (DataRow dRow in dtExcelData.Rows)
                                {
                                    hTextWriter.Write("<TR>");

                                    sTab = "";
                                    for (int j = 0; j < dtExcelData.Columns.Count; j++)
                                    {
                                        hTextWriter.Write("<Td>");
                                        hTextWriter.Write(System.Web.HttpUtility.HtmlEncode(sTab + Convert.ToString(dRow[j])));
                                        sTab = "\t";
                                        hTextWriter.Write("</Td>");
                                    }

                                    hTextWriter.Write("</TR>");
                                }
                            }
                            else
                            {
                                hTextWriter.Write("<Td bgColor='#106A86'>");
                                hTextWriter.Write("<B>");
                                hTextWriter.Write("<font color='#FFFFFF'>No records found</font>");
                                hTextWriter.Write("</B>");
                                hTextWriter.Write("</Td>");
                                hTextWriter.Write("</TR>");
                            }

                            hTextWriter.Write("</Table>");
                            hTextWriter.Write("</font>");

                        }
                        else
                        {
                            dataTransferInfo.ErrorMessage = new StringBuilder();
                            dataTransferInfo.ErrorMessage.Append("WriteToHtmlFormatExcel :: dtExcelData is null");
                        }

                        using (System.IO.TextWriter tWriteToExcelFile = new System.IO.StreamWriter(storePath))
                        {
                            tWriteToExcelFile.Write(sbResponse.ToString());
                            tWriteToExcelFile.Flush();
                            tWriteToExcelFile.Close();
                        }
                    }
                    sWData.Dispose();
                    sWData.Close();
                }
            }
            catch (Exception ex)
            {
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message + " " + ex.StackTrace);

            }
            finally
            {
                if (sbResponse != null)
                    sbResponse = null;

                sTab = null;

                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }


        private void WriteToOLEDBExcel(DataTransferInfo dataTransferInfo)
        {
            string connString = string.Empty;
            string sqlInsert = string.Empty;
            string sqlCreate = string.Empty;
            try
            {
                DataTable dtExcelData = dataTransferInfo.DataTable;
                string storePath = dataTransferInfo.DestinationExcelFilePath;
                string sheetName = dataTransferInfo.ExcelSheetName + "$";

                //connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + storePath + ";Extended Properties='Excel 12.0;ReadOnly=False;HDR=YES;'";
                connString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0 Xml;HDR=YES;'", storePath);

                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();

                    DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    //conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                    if (schemaTable.Rows.Count > 0)
                    {
                        DataRow schemaRow = schemaTable.Rows[0];
                        string sheet = schemaRow["TABLE_NAME"].ToString();

                        if (!sheet.EndsWith("_"))
                        {
                            using (OleDbCommand cmd = new OleDbCommand())
                            {
                                cmd.Connection = conn;

                                sqlInsert = GetSQLString(dtExcelData, sheetName, "INSERT", dataTransferInfo);
                                if (!string.IsNullOrWhiteSpace(sqlInsert))
                                {
                                    cmd.CommandText = sqlInsert;
                                    cmd.ExecuteNonQuery();
                                }

                                cmd.Dispose();
                            }
                        }
                    }
                    else
                    {
                        using (OleDbCommand cmd = new OleDbCommand())
                        {
                            cmd.Connection = conn;
                            sqlCreate = GetSQLString(dtExcelData, sheetName, "CREATE", dataTransferInfo);
                            if (!string.IsNullOrWhiteSpace(sqlCreate))
                            {
                                cmd.CommandText = sqlCreate;
                                cmd.ExecuteNonQuery();
                            }

                            sqlInsert = GetSQLString(dtExcelData, sheetName, "INSERT", dataTransferInfo);
                            if (!string.IsNullOrWhiteSpace(sqlInsert))
                            {
                                cmd.CommandText = sqlInsert;
                                cmd.ExecuteNonQuery();
                            }

                            cmd.Dispose();
                        }
                    }
                    conn.Close();
                }
            }
            catch (OleDbException ex)
            {
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message + " " + ex.StackTrace);
            }
            catch (Exception ex)
            {
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message + " " + ex.StackTrace);
            }
            finally
            {
                connString = null;
                sqlInsert = null;
                sqlCreate = null;
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }


        private string GetSQLString(DataTable dtExcelData, string sheetName, string type, DataTransferInfo dataTransferInfo)
        {
            string sColumnName = string.Empty;
            string sRowValue = string.Empty;
            string sqlSnippet = string.Empty;

            try
            {
                if (dtExcelData != null && dtExcelData.Rows.Count >= 1)
                {
                    if (type == "INSERT")
                    {
                        sqlSnippet = string.Format("INSERT INTO [{0}] (", sheetName);

                        foreach (DataColumn dcTemplate in dtExcelData.Columns)
                        {
                            if (string.IsNullOrWhiteSpace(sColumnName))
                                sColumnName = "[" + dcTemplate.ColumnName + "]";
                            else
                                sColumnName = sColumnName + ", [" + dcTemplate.ColumnName + "]";
                        }
                        sqlSnippet = string.Format("{0}{1}) VALUES (", sqlSnippet, sColumnName);

                        foreach (DataRow drTemplate in dtExcelData.Rows)
                        {
                            if (string.IsNullOrWhiteSpace(sRowValue))
                            {
                                for (int j = 0; j < dtExcelData.Columns.Count; j++)
                                {
                                    if (string.IsNullOrWhiteSpace(sRowValue))
                                    {
                                        //sRowValue = "'" + HttpContext.Current.Server.HtmlEncode(Convert.ToString(drTemplate[j])) + "'";
                                        sRowValue = "'" + Convert.ToString(drTemplate[j]) + "'";
                                    }
                                    else
                                    {
                                        //sRowValue = sRowValue + ", '" + HttpContext.Current.Server.HtmlEncode(Convert.ToString(drTemplate[j])) + "'";
                                        sRowValue = sRowValue + ", '" + Convert.ToString(drTemplate[j]) + "'";
                                    }
                                }
                            }
                        }
                        sqlSnippet = string.Format("{0}{1}) ", sqlSnippet, sRowValue);
                    }
                    else
                    {
                        sqlSnippet = string.Empty;
                        if (!string.IsNullOrWhiteSpace(sheetName) && sheetName.Length > 1)
                        {
                            sqlSnippet = string.Format("CREATE TABLE [{0}] (", sheetName.Substring(0, sheetName.Length - 1));

                            foreach (DataColumn dcTemplate in dtExcelData.Columns)
                            {
                                if (string.IsNullOrWhiteSpace(sColumnName))
                                    sColumnName = "[" + dcTemplate.ColumnName + "] TEXT";
                                else
                                    sColumnName = sColumnName + ", [" + dcTemplate.ColumnName + "] TEXT";
                            }
                            sqlSnippet = string.Format("{0}{1})", sqlSnippet, sColumnName);
                        }
                    }
                }
                else
                {
                    dataTransferInfo.ErrorMessage = new StringBuilder();
                    dataTransferInfo.ErrorMessage.Append("WriteToOLEDBExcel :: GetSQLString :: dtExcelData is null");
                }
            }
            catch (Exception ex)
            {
                dataTransferInfo.ErrorMessage = new StringBuilder();
                dataTransferInfo.ErrorMessage.Append(ex.Message + " " + ex.StackTrace);
            }
            finally
            {
                sColumnName = null;
                sRowValue = null;
            }
            return sqlSnippet;
        }
    }
}
