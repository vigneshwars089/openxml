﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DigiOPS.TechFoundation.DataTransfer;
using DigiOPS.TechFoundation.UserManagement;
using DigiOPS.TechFoundation.DataAccessLayer;
using DigiOPS.TechFoundation.Entities;
using DigiOPS.TechFoundation.Security.ConsoleTest;
using DigiOPS.TechFoundation.Security;
using System.IO;
using System.Xml;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.Configuration;


namespace UnitTest1
{
    [TestClass]
    public class UnitTest1
    {
        /////===============================   <add name="Conn" connectionString="Data Source=ctsc00617635601;Initial Catalog=EMT_Main_Sprint;User ID=emtuser;Password=password-1" providerName="System.Data.SqlClient"/>
        /*
                [TestMethod]
                public void DynamicFieldReadEmt()
                {


                    DataElementEntity DataElement = new DataElementEntity();//to Read on EMT
                    ConfigurationInfo DataElementEnt = new ConfigurationInfo();
                    DataElementEnt = (ConfigurationInfo)DataElement;
                    DataElementEnt.AppID = "EMT";
                    DataElement.CaseID = "21573";



                    ConfigurationFactory configfactory = new ConfigurationFactory();
                    var config = configfactory.GetConfigurationHandler("DynamicField");
                    //List<DataElementEntity> dataElements = new List<DataElementEntity>();
                    List<DataElementEntity> dataElementsList = new List<DataElementEntity>();

                    // ArrayList dataElements = new ArrayList();
                    config.ReadConfiguration(DataElementEnt, ref dataElementsList);
                    int n = dataElementsList.Count;
                    Assert.IsNotNull(n);
                }

                [TestMethod]
                public void DynamicFieldReadEmtNegative()
                {


                    DataElementEntity DataElement = new DataElementEntity();//to Read on EMT
                    ConfigurationInfo DataElementEnt = new ConfigurationInfo();
                   DataElementEnt = (ConfigurationInfo)DataElement;
                    DataElementEnt.AppID = "EMT";
                    //DataElement.CaseID = "21573";



                    ConfigurationFactory configfactory = new ConfigurationFactory();
                    var config = configfactory.GetConfigurationHandler("DynamicField");
                    //List<DataElementEntity> dataElements = new List<DataElementEntity>();
                    List<DataElementEntity> dataElementsList = new List<DataElementEntity>();

                    // ArrayList dataElements = new ArrayList();
                    config.ReadConfiguration(DataElementEnt, ref dataElementsList);
                    int n = dataElementsList.Count;
                    Assert.IsTrue(n==0);

                }



                [TestMethod]
                [ExpectedException(typeof(InvalidCastException))]
                public void DynamicFieldReadEmtException()
                {
                    try
                    {
                        DataElementEntity DataElement = new DataElementEntity();//to Read on EMT
                        ConfigurationInfo DataElementEnt = new ConfigurationInfo();
                        //DataElementEnt = (ConfigurationInfo)DataElement;
                        DataElementEnt.AppID = "EMT";
                        DataElement.CaseID = null;



                        ConfigurationFactory configfactory = new ConfigurationFactory();
                        var config = configfactory.GetConfigurationHandler("DynamicField");
                        //List<DataElementEntity> dataElements = new List<DataElementEntity>();
                        List<DataElementEntity> dataElementsList = new List<DataElementEntity>();

                        // ArrayList dataElements = new ArrayList();
                        config.ReadConfiguration(DataElementEnt, ref dataElementsList);
                    }
                    catch (Exception ex)
                    {
                        //Assert.AreEqual("Password's do not match.", ex.Message);
                        throw;

                    }
            
                }
                */
       

        [TestMethod]
        public void DynamicFieldQuartWrite()
        {
            DataElementEntity DataElement = new DataElementEntity();//to write on quart subprocessID,ELementID,ELEMEntname,datatypeId
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "QUART";
            DataElement.ElementId = 6;
            DataElement.ElementName = "SNo3";
            DataElement.FieldType = "Transaction";
            DataElement.ElementTypeId = 1;
            DataElement.DataTypeId = 5;
            DataElement.splChars = null;
            DataElement.ElementLength = 9;
            DataElement.CodeGroupId = null;
            DataElement.SequenceNo = 1;
            DataElement.MandatoryElement = true;
            DataElement.AuditFormElement = true;
            DataElement.UniqueElement = false;
            DataElement.GridViewElement = false;
            DataElement.IsReportField = false;
            DataElement.SearchableElement = true;
            DataElement.SamplingThreshold = false;
            DataElement.IsDirectAuditLevel = false;
            DataElement.DirectAuditLevelId = 0;
            DataElement.minAuditRange = null;
            DataElement.maxAuditRange = null;
            DataElement.minSamplingRange = null;
            DataElement.maxSamplingRange = null;
            DataElement.DataEntryRoleId = "3";
            DataElement.createdBy = "6";
            DataElement.modifiedBy = "9";
            DataElementEnt._SubProcessID = 4;
            DataElementEnt.eventAction = "INSERT";
            DataElementEnt._ElementCount = 10;
            string value = null;
            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            config.WriteConfiguration(DataElementEnt, ref value);


            Assert.IsTrue(value == "1");
            
        }

        [TestMethod]
        public void DynamicFieldQuartWritenegative()
        {
            DataElementEntity DataElement = new DataElementEntity();//to write on quart subprocessID,ELementID,ELEMEntname,datatypeId
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
           // DataElementEnt = (ConfigurationInfo)DataElement;
         //   DataElementEnt.AppID = "QUART";
          //  DataElement.ElementId = 4;
          //  DataElement.ElementName = "SNo1";
        //    DataElement.FieldType = "Transaction";
          //  DataElement.ElementTypeId = 1;
         //   DataElement.DataTypeId = 5;
            DataElement.splChars = null;
            DataElement.ElementLength = 9;
            DataElement.CodeGroupId = null;
            DataElement.SequenceNo = 1;
            DataElement.MandatoryElement = true;
            DataElement.AuditFormElement = true;
            DataElement.UniqueElement = false;
            DataElement.GridViewElement = false;
            DataElement.IsReportField = false;
            DataElement.SearchableElement = true;
            DataElement.SamplingThreshold = false;
            DataElement.IsDirectAuditLevel = false;
            DataElement.DirectAuditLevelId = 0;
            DataElement.minAuditRange = null;
            DataElement.maxAuditRange = null;
            DataElement.minSamplingRange = null;
            DataElement.maxSamplingRange = null;
            DataElement.DataEntryRoleId = "3";
            DataElement.createdBy = "6";
            DataElement.modifiedBy = "9";
          //  DataElementEnt._SubProcessID = 4;
            DataElementEnt.eventAction = "INSERT";
            DataElementEnt._ElementCount = 10;
            string value = null;
            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            config.WriteConfiguration(DataElementEnt, ref value);


            Assert.IsTrue(value == "0"|| value==null);

        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void DynamicWriteQuartException()
        {
          try{
            DataElementEntity DataElement = new DataElementEntity();//to write on quart subprocessID,ELementID,ELEMEntname,datatypeId
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
          DataElementEnt.AppID = "QUART";
          //  DataElement.ElementId = 4;
          //  DataElement.ElementName = "SNo1";
        //    DataElement.FieldType = "Transaction";
          //  DataElement.ElementTypeId = 1;
         //   DataElement.DataTypeId = 5;
            //DataElement.splChars = null;
            //DataElement.ElementLength = 9;
            //DataElement.CodeGroupId = null;
            //DataElement.SequenceNo = 1;
            //DataElement.MandatoryElement = true;
            //DataElement.AuditFormElement = true;
            //DataElement.UniqueElement = false;
            //DataElement.GridViewElement = false;
            //DataElement.IsReportField = false;
            //DataElement.SearchableElement = true;
            //DataElement.SamplingThreshold = false;
            //DataElement.IsDirectAuditLevel = false;
            //DataElement.DirectAuditLevelId = 0;
            //DataElement.minAuditRange = null;
            //DataElement.maxAuditRange = null;
            //DataElement.minSamplingRange = null;
            //DataElement.maxSamplingRange = null;
            //DataElement.DataEntryRoleId = "3";
            //DataElement.createdBy = "6";
            //DataElement.modifiedBy = "9";
          //  DataElementEnt._SubProcessID = 4;
            DataElementEnt.eventAction = "INSERT";
            DataElementEnt._ElementCount = 10;
            string value = null;
            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            config.WriteConfiguration(DataElementEnt, ref value);
            throw new System.Exception(DataElement.ErrorMessage.ToString());
                    }
                    catch (Exception ex)
                    {
                        //Assert.AreEqual("Password's do not match.", ex.Message);
                        throw;

                    }



        }


        

       [TestMethod]
        public void DynamicFieldQuartRead()
        {
            DataElementEntity DataElement = new DataElementEntity();
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "QUART";

            DataElement._SubProcessID = 3;
            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            //List<DataElementEntity> dataElements = new List<DataElementEntity>();
            List<DataElementEntity> dataElementsList = new List<DataElementEntity>();

            // ArrayList dataElements = new ArrayList();
            config.ReadConfiguration(DataElementEnt, ref dataElementsList);
            int n = dataElementsList.Count;
            Assert.IsTrue(n == 1);




        }



       [TestMethod]
       public void DynamicFieldQuartReadnegative()
       {
           DataElementEntity DataElement = new DataElementEntity();
           ConfigurationInfo DataElementEnt = new ConfigurationInfo();
           DataElementEnt = (ConfigurationInfo)DataElement;
       //    DataElementEnt.AppID = "QUART";

           DataElement._SubProcessID = 3;
           ConfigurationFactory configfactory = new ConfigurationFactory();
           var config = configfactory.GetConfigurationHandler("DynamicField");
           //List<DataElementEntity> dataElements = new List<DataElementEntity>();
           List<DataElementEntity> dataElementsList = new List<DataElementEntity>();

           // ArrayList dataElements = new ArrayList();
           config.ReadConfiguration(DataElementEnt, ref dataElementsList);
           int n = dataElementsList.Count;
           Assert.IsTrue(n == 0);

}
        




        [TestMethod]
        public void DynamicFieldEmtWrite()
        {
              DataElementEntity DataElement = new DataElementEntity();//to write on EMT//change fieldmasterID,fieldname,datatypeID,fielddatatypeID
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "EMT";
            DataElement.CountryID=4;
            DataElement.MailBoxID =2;
            DataElement.defaultValue="";
            DataElement.fieldname = "fieldname9";
            DataElement.FieldTypeID ="10";
            DataElement.FieldDataTypeID ="20";
            DataElement.ValidationTypeID =1;
            DataElement.FieldMaxLength =9;
            DataElement.UserId = "319621";
            DataElement.chkactive=true;
            DataElement.Mandatory=true;
            DataElement.btnMap ="Configure";
            DataElement.FieldMasterId =112;
            string value = null;

            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            config.WriteConfiguration(DataElementEnt, ref value);


            Assert.IsTrue(value == "1");
        }

        [TestMethod]
        public void DynamicFieldEmtWriteNegative()
        {
            DataElementEntity DataElement = new DataElementEntity();//to write on EMT//change fieldmasterID,fieldname,datatypeID,fielddatatypeID
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
            DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "EMT";
            DataElement.CountryID = 4;
            DataElement.MailBoxID = 2;
            DataElement.defaultValue = "";
        //    DataElement.fieldname = "fieldname7";
            DataElement.FieldTypeID = "8";
            DataElement.FieldDataTypeID = "7";
            DataElement.ValidationTypeID = 1;
            DataElement.FieldMaxLength = 9;
            DataElement.UserId = "319620";
            DataElement.chkactive = true;
            DataElement.Mandatory = true;
            DataElement.btnMap = "Configure";
            DataElement.FieldMasterId = 109;
            string value = null;

            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            config.WriteConfiguration(DataElementEnt, ref value);


            Assert.IsTrue(value == "0" || value == null);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void DynamicFieldEmtWriteException()
        {
            try{
             DataElementEntity DataElement = new DataElementEntity();//to write on EMT//change fieldmasterID,fieldname,datatypeID,fielddatatypeID
            ConfigurationInfo DataElementEnt = new ConfigurationInfo();
           // DataElementEnt = (ConfigurationInfo)DataElement;
            DataElementEnt.AppID = "EMT";
            DataElement.CountryID=4;
            DataElement.MailBoxID =2;
            DataElement.defaultValue="";
            DataElement.fieldname = "fieldname7";
            DataElement.FieldTypeID ="8";
            DataElement.FieldDataTypeID ="7";
            DataElement.ValidationTypeID =1;
            DataElement.FieldMaxLength =9;
            DataElement.UserId = "319620";
            DataElement.chkactive=true;
            DataElement.Mandatory=true;
            DataElement.btnMap ="Configure";
            DataElement.FieldMasterId =109;
            string value = null;

            ConfigurationFactory configfactory = new ConfigurationFactory();
            var config = configfactory.GetConfigurationHandler("DynamicField");
            config.WriteConfiguration(DataElementEnt, ref value);

            throw new System.Exception(DataElement.ErrorMessage.ToString());
                    }
                    catch (NullReferenceException ex)
                    {
                        //Assert.AreEqual("Password's do not match.", ex.Message);
                        throw;

                    }
         
        }



       
        

        

        

        //------------------------------------------------------------------------------

        //USER MANAGEMNT
         
           [TestMethod]
           public void USERcreateUserNegative()
           {

             UserInfo objRoleInfo = new UserInfo();
               objRoleInfo.AppID = "EMT";
           
               //objRoleInfo.RoleId = 2;
               objRoleInfo.UserID = "2222";
               objRoleInfo.FirstName = "a";
               objRoleInfo.LastName = "z";
               objRoleInfo.EmailID = "az@gmail.com";
               objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                 objRoleInfo.EncryptConfirmPassword="D7UO9OEm6XgkGHSMrVkDwg==";
               objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
               objRoleInfo.IsActive = true;
               objRoleInfo.RoleId =1;
              BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.CreateUser(objRoleInfo);
            
               Assert.IsTrue(n<=0);
            
           }

           [TestMethod]
           public void USERcreateUserPositive()
           {
              UserInfo objRoleInfo = new UserInfo();
               objRoleInfo.AppID = "EMT";
               objRoleInfo.UserID = "5555225453";
               objRoleInfo.FirstName = "a";
               objRoleInfo.LastName = "z";
               objRoleInfo.EmailID = "az@gmail.com";
               objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
               objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";

               objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
               objRoleInfo.IsActive = true;
               objRoleInfo.RoleId = 1;
               objRoleInfo.UTCTime = DateTime.Now.ToString();
               //objRoleInfo.RoleId = 2;
           
              BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.CreateUser(objRoleInfo);

               Assert.IsTrue(n > 0);

           } 

           [TestMethod]
           [ExpectedException(typeof(NullReferenceException))]
           public void USERcreateUserException()
           {
           try{
             UserInfo objRoleInfo = new UserInfo();
               objRoleInfo.AppID = "EMT";
           
               //objRoleInfo.RoleId = 2;
               objRoleInfo.UserID = "2222";
               objRoleInfo.FirstName = "a";
               objRoleInfo.LastName = "z";
               objRoleInfo.EmailID = "az@gmail.com";
               objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                 objRoleInfo.EncryptConfirmPassword="D7UO9OEmuyfhgfghasf6XgkGHSMrVkDwg==";
               objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
               objRoleInfo.IsActive = true;
               objRoleInfo.RoleId =1;
              BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.CreateUser(objRoleInfo);

           
               throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
               }
               catch(Exception ex)
               {
                   //Assert.AreEqual("Password's do not match.", ex.Message);
                   throw;

               }
           }

           [TestMethod]
           public void USERupdateUserPositive()
           {

               UserInfo objRoleInfo = new UserInfo();
               objRoleInfo.AppID = "EMT";
               objRoleInfo.UserID = "55225453";
               objRoleInfo.FirstName = "a";
               objRoleInfo.LastName = "z";
               objRoleInfo.EmailID = "az@gmail.com";
               objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
               objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";

               objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
               objRoleInfo.IsActive = true;
               objRoleInfo.RoleId = 1;
               objRoleInfo.UTCTime = DateTime.Now.ToString();
               //objRoleInfo.RoleId = 2;

          
                BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.UpdateUser(objRoleInfo);

               Assert.IsTrue(n > 0);

           }
           [TestMethod]
           public void USERupdateUserNegative()
           {
               UserInfo objRoleInfo = new UserInfo();
               objRoleInfo.AppID = "EMT";
                       objRoleInfo.UserID = "234234234";
                       objRoleInfo.FirstName = "a";
                       objRoleInfo.LastName = "z";
                       objRoleInfo.EmailID = "az@gmail.com";
                       objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                       objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                       objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
                       objRoleInfo.RoleId = 1;
                       objRoleInfo.IsActive = true;
                BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.UpdateUser(objRoleInfo);

               Assert.IsTrue(n <= 0);

           }


           [TestMethod]
           [ExpectedException(typeof(NullReferenceException))]
           public void USERupdateUserException()
           {
               try
               {
                   UserInfo objRoleInfo = new UserInfo();
               objRoleInfo.AppID = "EMT";
                       objRoleInfo.UserID = "234234234";
                       objRoleInfo.FirstName = "a";
                       objRoleInfo.LastName = "z";
                       objRoleInfo.EmailID = "az@gmail.com";
                       objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                       objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                       objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
                       objRoleInfo.RoleId = 1;
                       objRoleInfo.IsActive = true;
                BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.UpdateUser(objRoleInfo);


                   throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
               }
               catch (Exception ex)
               {
                  // Assert.AreEqual("Password's do not match.", ex.Message);
                   throw;

               }
           }

        [TestMethod]
           public void USERassignUserRolePositive()
           {
                   UserRoleInfo objRoleInfo = new UserRoleInfo();
                       UserInfo user = new UserInfo();
                       objRoleInfo.AppID = "EMT";
                       user.UserID = "195175";
                       user.CountryId = "1";
                       objRoleInfo.User = user;
                       RoleInfo role = new RoleInfo();
                       role.RoleId = 2;
                       List<RoleInfo> mine = new List<RoleInfo>();
                       mine.Add(role);
                       objRoleInfo.UserRoles = mine;
               BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.AssignUserRole(objRoleInfo);

               Assert.IsTrue(n > 0);

           }
           [TestMethod]
           public void USERassignUserRoleNegative()
           {
               UserRoleInfo objRoleInfo = new UserRoleInfo();
               UserInfo user = new UserInfo();
               user.UserID = "195174";
               user.CountryId = "1";
               objRoleInfo.User = user;
              RoleInfo role = new RoleInfo();
              role.RoleId = 2;
              List<RoleInfo> mine = new List<RoleInfo>();
              mine.Add(role);
              objRoleInfo.UserRoles = mine;

               BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.AssignUserRole(objRoleInfo);

               Assert.IsTrue(n <= 0);

           }

           [TestMethod]
           [ExpectedException(typeof(NullReferenceException))]
           public void USERassignUserRoleException()
           {
               try
               {
                   UserRoleInfo objRoleInfo = new UserRoleInfo();
               UserInfo user = new UserInfo();
               user.UserID = "195174";
               user.CountryId = "1";
               objRoleInfo.User = user;
              RoleInfo role = new RoleInfo();
              role.RoleId = 2;
              List<RoleInfo> mine = new List<RoleInfo>();
              mine.Add(role);
              objRoleInfo.UserRoles = mine;
                    BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.AssignUserRole(objRoleInfo);


                   throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
               }
               catch 
               {
    
                   throw;

               }
           }


           [TestMethod]
           public void USERupdateUserRolePositive()
           {
               UserRoleInfo objRoleInfo = new UserRoleInfo();
               UserInfo user = new UserInfo();
               objRoleInfo.AppID = "EMT";
               user.UserID = "195174";
               user.CountryId = "4";
               objRoleInfo.User = user;
               objRoleInfo.UserRoleMapId = "1";
               BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();

        
          
               int n = BASECUSTOM.UpdateUserRole(objRoleInfo);

               Assert.IsTrue(n > 0);

           }

           [TestMethod]
           public void USERupdateUserRoleNegative()
           {
                UserRoleInfo objRoleInfo = new UserRoleInfo();
               UserInfo user = new UserInfo();
               user.UserID = "195174";
               user.CountryId = "4";
               objRoleInfo.User = user;
               objRoleInfo.UserRoleMapId = "1";
               BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.UpdateUserRole(objRoleInfo);

               Assert.IsTrue(n <= 0);

           }


           [TestMethod]
           [ExpectedException(typeof(NullReferenceException))]
           public void USERupdateUserRoleException()
           {
               try
               {
                    UserRoleInfo objRoleInfo = new UserRoleInfo();
               UserInfo user = new UserInfo();
               user.UserID = "195174";
               user.CountryId = "4";
               objRoleInfo.User = user;
               objRoleInfo.UserRoleMapId = "1";
                   BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.UpdateUserRole(objRoleInfo);


                   throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
               }
               catch
               {
                
                   throw;

               }
           }


           [TestMethod]
           public void USERdeleteUserRoleNegative()
           {
              UserRoleInfo objRoleInfo = new UserRoleInfo();
           
               objRoleInfo.UserRoleMapId = "1";
                BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.DeleteUserRole(objRoleInfo);

               Assert.IsTrue(n <= 0);

           }

           [TestMethod]
           public void USERdeleteUserRolePositive()
           {
               UserRoleInfo objRoleInfo = new UserRoleInfo();
               objRoleInfo.AppID = "EMT";
               objRoleInfo.UserRoleMapId = "1";
                BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.DeleteUserRole(objRoleInfo);

               Assert.IsTrue(n > 0);

           }

           [TestMethod]
           [ExpectedException(typeof(NullReferenceException))]
           public void USERdeleteUserRoleException()
           {
               try
               {
                  UserRoleInfo objRoleInfo = new UserRoleInfo();
           
               objRoleInfo.UserRoleMapId = "1";
                   BaseCustomUserManagement BASECUSTOM = new BaseCustomUserManagement();
          
               int n = BASECUSTOM.DeleteUserRole(objRoleInfo);
                 

                   throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
               }
               catch
               {
                   // Assert.AreEqual("Password's do not match.", ex.Message);
                   throw;

               }
           }

        //------------------------------------------------------------------------------
        
                //DATA ACCESS LAYER

        
              [TestMethod]
                public void DATAcreateNegative()
                {
                    UserInfo objRoleInfo = new UserInfo();

                    objRoleInfo.AppID = "EMT";
                    objRoleInfo.UserID = "552325453";
                    objRoleInfo.FirstName = "a";
                    objRoleInfo.LastName = "z";
                    objRoleInfo.EmailID = "az@gmail.com";
                    objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                    //objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";

                    objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
                    objRoleInfo.IsActive = true;
                    objRoleInfo.RoleId = 1;
                    objRoleInfo.UTCTime = DateTime.Now.ToString();
                    //objRoleInfo.RoleId = 2;
                    //objRoleInfo.UserManagingType="";

                    //objRoleInfo.UTCTime = "";
                    EMTUserRepository objUserRepository = new EMTUserRepository();
                    int n = objUserRepository.Create(objRoleInfo);

                    Assert.IsTrue(n <= 0);

                }

              [TestMethod]
                public void DATAcreatePositive()
                {
                    UserInfo objRoleInfo = new UserInfo();

                   
                    objRoleInfo.AppID = "EMT";
                    objRoleInfo.UserID = "55232335453";
                    objRoleInfo.FirstName = "a";
                    objRoleInfo.LastName = "z";
                    objRoleInfo.EmailID = "az@gmail.com";
                    objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                    //objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";

                    objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
                    objRoleInfo.IsActive = true;
                    objRoleInfo.RoleId = 1;
                    objRoleInfo.UTCTime = DateTime.Now.ToString();
                    //objRoleInfo.RoleId = 2;
                    //objRoleInfo.UserManagingType="";

                    //objRoleInfo.UTCTime = "";
                    EMTUserRepository objUserRepository = new EMTUserRepository();
                    int n = objUserRepository.Create(objRoleInfo);
       
                    Assert.IsTrue(n > 0);

                }

         [TestMethod]
                [ExpectedException(typeof(SqlException))]
                public void DATAcreateException()
                {
                    try
                    {
                        UserInfo objRoleInfo = new UserInfo();
            //objRoleInfo.AppID = "EMT";
           
            //objRoleInfo.RoleId = 2;
            objRoleInfo.UserID = "2222";
            objRoleInfo.FirstName = "a";
            objRoleInfo.LastName = "z";
            objRoleInfo.EmailID = "az@gmail.com";
            objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
            objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
            objRoleInfo.IsActive = true;
            objRoleInfo.RoleId =1;
            //objRoleInfo.UserManagingType="";
           
            //objRoleInfo.UTCTime = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.Create(objRoleInfo);
            
            Console.WriteLine(n);
            Console.ReadLine();


                        throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
                    }
                    catch (Exception ex)
                    {
                        //Assert.AreEqual("Password's do not match.", ex.Message);
                        throw;

                    }
                }

                [TestMethod]
                public void DATAupdatePositive()
                {
                     UserInfo objRoleInfo = new UserInfo();
                     objRoleInfo.AppID = "EMT";
                     objRoleInfo.UserID = "552325453";
                     objRoleInfo.FirstName = "a";
                     objRoleInfo.LastName = "z";
                     objRoleInfo.EmailID = "az@gmail.com";
                     objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                     //objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";

                     objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
                     objRoleInfo.IsActive = true;
                     objRoleInfo.RoleId = 1;
                     objRoleInfo.UTCTime = DateTime.Now.ToString();
            
                    EMTUserRepository objUserRepository = new EMTUserRepository();
                    int n = objUserRepository.Update(objRoleInfo);

                    Assert.IsTrue(n > 0);

                }
                [TestMethod]
                public void DATAupdateNegative()
                {
                    UserInfo objRoleInfo = new UserInfo();
                    objRoleInfo.AppID = "EMT";
                    objRoleInfo.UserID = "55232345555453";
                    objRoleInfo.FirstName = "a";
                    objRoleInfo.LastName = "z";
                    objRoleInfo.EmailID = "az@gmail.com";
                    objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
                    //objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";

                    objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
                    objRoleInfo.IsActive = true;
                    objRoleInfo.RoleId = 1;
                    objRoleInfo.UTCTime = DateTime.Now.ToString();
            
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.Update(objRoleInfo);

                    Assert.IsTrue(n <= 0);

                }


               [TestMethod]
                [ExpectedException(typeof(SqlException))]
                public void DATAupdateException()
                {
                    try
                    {
                        UserInfo objRoleInfo = new UserInfo();
            objRoleInfo.UserID = "234234234";
            objRoleInfo.FirstName = "a";
            objRoleInfo.LastName = "z";
            objRoleInfo.EmailID = "az@gmail.com";
            objRoleInfo.EncryptPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
            objRoleInfo.EncryptConfirmPassword = "D7UO9OEm6XgkGHSMrVkDwg==";
            objRoleInfo.TimeZone = "Pacific Standard Time (Mexico)";
            objRoleInfo.RoleId = 1;
            objRoleInfo.IsActive = true;
            
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.Update(objRoleInfo);


                        throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
                    }
                    catch (Exception ex)
                    {
                        //Assert.AreEqual("Password's do not match.", ex.Message);
                        throw;

                    }
                }
       
               [TestMethod]
                public void DATAassignRolePositive()
                {
                    UserRoleInfo objRoleInfo = new UserRoleInfo();
                    UserInfo user = new UserInfo();
                    user.UserID = "195175";
                    user.CountryId = "1";
                    objRoleInfo.User = user;
                    RoleInfo role = new RoleInfo();
                    role.RoleId = 2;
                    List<RoleInfo> mine = new List<RoleInfo>();
                    mine.Add(role);
                    objRoleInfo.UserRoles = mine;
                    EMTUserRepository objUserRepository = new EMTUserRepository();
                    int n = objUserRepository.AssignRole(objRoleInfo);
                    Assert.IsTrue(n > 0);

                }
                [TestMethod]
                public void DATAassignRoleNegative()
                {
                     UserRoleInfo objRoleInfo = new UserRoleInfo();
            UserInfo user = new UserInfo();
            user.UserID = "";
            user.CountryId = "1";
            objRoleInfo.User = user;
           RoleInfo role = new RoleInfo();
           role.RoleId = 2;
           List<RoleInfo> mine = new List<RoleInfo>();
           mine.Add(role);
           objRoleInfo.UserRoles = mine;
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.AssignRole(objRoleInfo);

                    Assert.IsTrue(n <= 0);

                }

                [TestMethod]
                [ExpectedException(typeof(NullReferenceException))]
                public void DATAassignRoleException()
                {
                    try
                    {
                         UserRoleInfo objRoleInfo = new UserRoleInfo();
            UserInfo user = new UserInfo();
            user.UserID = "";
            user.CountryId = "1";
            objRoleInfo.User = user;
           RoleInfo role = new RoleInfo();
           role.RoleId = 2;
           List<RoleInfo> mine = new List<RoleInfo>();
           mine.Add(role);
           objRoleInfo.UserRoles = mine;
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.AssignRole(objRoleInfo);


                        throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
                    }
                    catch
                    {
                       
                        throw;

                    }
                }


                [TestMethod]
                public void DATAupdateRolePositive()
                {
                    UserRoleInfo objRoleInfo = new UserRoleInfo();
            UserInfo user = new UserInfo();
            user.UserID = "195174";
            user.CountryId = "10";
            objRoleInfo.User = user;
            objRoleInfo.UserRoleMapId = "4";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.UpdateUserRole(objRoleInfo);

                    Assert.IsTrue(n > 0);

                }

            


                [TestMethod]
                [ExpectedException(typeof(NullReferenceException))]
                public void DATAupdateRoleException()
                {
                    try
                    {
                        UserRoleInfo objRoleInfo = new UserRoleInfo();
            UserInfo user = new UserInfo();
            user.UserID = "";
            user.CountryId = "4";
            objRoleInfo.User = user;
            objRoleInfo.UserRoleMapId = "1";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.UpdateUserRole(objRoleInfo);


                        throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
                    }
                    catch
                    {
                       
                        throw;

                    }
                }


                [TestMethod]
                public void DATAdeleteRoleNegative()
                {
                    UserRoleInfo objRoleInfo = new UserRoleInfo();
           
            objRoleInfo.UserRoleMapId = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.DeleteUserRole(objRoleInfo);

                    Assert.IsTrue(n <= 0);

                }

                [TestMethod]
                public void DATAdeleteRolePositive()
                {UserRoleInfo objRoleInfo = new UserRoleInfo();
           
            objRoleInfo.UserRoleMapId = "1";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.DeleteUserRole(objRoleInfo);

                    Assert.IsTrue(n > 0);

                }

                [TestMethod]
                [ExpectedException(typeof(NullReferenceException))]
                public void DATAdeleteRoleException()
                {
                    try
                    {
                       UserRoleInfo objRoleInfo = new UserRoleInfo();
           
            objRoleInfo.UserRoleMapId = "";
            EMTUserRepository objUserRepository = new EMTUserRepository();
            int n = objUserRepository.DeleteUserRole(objRoleInfo);


                        throw new System.Exception(objRoleInfo.ErrorMessage.ToString());
                    }
                    catch
                    {
                       
                        throw;

                    }
                }
               
        
      
        

/*
        //---------------------------------------------------------------------------------
        //DATA TRANSFER 


        [TestMethod]
        public void expotHtmlpositive()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("AssociateID");
            DataRow oneRow = dataTable.NewRow();
            oneRow["AssociateID"] = "454545";
            dataTable.Rows.Add(oneRow);

            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Html";
            //dataTransferInfo.ExcelExportType = "OleDB";
            dataTransferInfo.DataTable = dataTable;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
            //dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);

            string errorMessage = "";
            if (dataTransferInfo.ErrorMessage != null)
            {
                errorMessage = dataTransferInfo.ErrorMessage.ToString();
            }

            Assert.IsTrue(File.Exists(dataTransferInfo.DestinationExcelFilePath));

        }

        [TestMethod]
        public void expotHtmlpositive2()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("AssociateID");
            DataRow oneRow = dataTable.NewRow();
            oneRow["AssociateID"] = "454545";
            dataTable.Rows.Add(oneRow);

            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Html";
            //dataTransferInfo.ExcelExportType = "OleDB";
            dataTransferInfo.DataTable = dataTable;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
            //dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);

            string testData = System.IO.File.ReadAllText(@"D:\\test\\blank.html");

            Assert.IsNotNull(testData);
        }


        [TestMethod]
        public void expotHtmlnegative()
        {
            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Html";
            //dataTransferInfo.ExcelExportType = "OleDB";
            dataTransferInfo.DataTable = null;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
            //dataTransferInfo.ExcelSheetName = "TestSheetName";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);


            string testData = System.IO.File.ReadAllText(@"D:\\test\\blank.html");
            bool n= true;
            if(string.IsNullOrEmpty(testData))
            {
               n=false;
            }
            Assert.IsFalse(n);

        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void exporthtmlexception()
        {
            try
            {

                //DataTable dataTable = new DataTable();
                //dataTable.Columns.Add("AssociateID");
                //DataRow oneRow = dataTable.NewRow();
                //oneRow["AssociateID"] = "454545";
                //dataTable.Rows.Add(oneRow);

                DataTransferInfo dataTransferInfo = new DataTransferInfo();
                dataTransferInfo.ExcelExportType = "Html";
                //dataTransferInfo.ExcelExportType = "OleDB";
                dataTransferInfo.DataTable = null;
                dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
                //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
                //dataTransferInfo.ExcelSheetName = "TestSheetName";

                DataTransferFactory dataTransferFactory = new DataTransferFactory();
                var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
                dataTransferExcel.Export(dataTransferInfo);

                throw new System.Exception(dataTransferInfo.ErrorMessage.ToString());
            }
            catch(Exception ex)
            {
                Assert.AreEqual("WriteToHtmlFormatExcel :: dtExcelData is null", ex.Message);
                throw;
            }



        }

        
        

        */



            //string errorMessage = "";
           // if (dataTransferInfo.ErrorMessage != null)
           // {
           //     errorMessage = dataTransferInfo.ErrorMessage.ToString();
          //  }
        /*
        [TestMethod]
        public void ExcelImportNegative()
        {
            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.InputExcelFilePath = @"D:\\test\\blank.html";
            dataTransferInfo.ExcelSheetName = null;

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Import(dataTransferInfo);

            Assert.IsNull(dataTransferInfo.DataTable);

        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void ExcelImportexception()
        {
            try
            {
                DataTransferInfo dataTransferInfo = new DataTransferInfo();
                dataTransferInfo.InputExcelFilePath = @"D:\\test\\blank.html";
                dataTransferInfo.ExcelSheetName = null;

                DataTransferFactory dataTransferFactory = new DataTransferFactory();
                var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
                dataTransferExcel.Import(dataTransferInfo);

                if (dataTransferInfo.DataTable == null)
                {
                    throw new System.Exception(dataTransferInfo.ErrorMessage.ToString());
                }
            }
            catch (Exception ex)
            {
                //Assert.AreEqual("WriteToHtmlFormatExcel :: dtExcelData is null", ex.Message);
                throw;
            }
        }





        [TestMethod]
        public void expotOleDb()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("AssociateID");
            DataRow oneRow = dataTable.NewRow();
            oneRow["AssociateID"] = "454545";
            dataTable.Rows.Add(oneRow);

            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Excel";
            dataTransferInfo.DataTable = dataTable;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            dataTransferInfo.ExcelSheetName = "Sheet1";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);

            Assert.IsTrue(File.Exists(dataTransferInfo.DestinationExcelFilePath));
        }



        [TestMethod]
        public void exportOleDbnegative()
        {
            //DataTable dataTable = new DataTable();
            //dataTable.Columns.Add("AssociateID");
            //DataRow oneRow = dataTable.NewRow();
            //oneRow["AssociateID"] = "454545";
            //dataTable.Rows.Add(oneRow);

            DataTransferInfo dataTransferInfo = new DataTransferInfo();
            dataTransferInfo.ExcelExportType = "Excel";
            //dataTransferInfo.DataTable = dataTable;
            dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
            dataTransferInfo.ExcelSheetName = "Sheet1";

            DataTransferFactory dataTransferFactory = new DataTransferFactory();
            var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
            dataTransferExcel.Export(dataTransferInfo);


            Assert.IsFalse(File.Exists(dataTransferInfo.DestinationExcelFilePath));
        }


        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public void exportOleDbexception()
        {
            try
            {

                //DataTable dataTable = new DataTable();
                //dataTable.Columns.Add("AssociateID");
                //DataRow oneRow = dataTable.NewRow();
                //oneRow["AssociateID"] = "454545";
                //dataTable.Rows.Add(oneRow);

                DataTransferInfo dataTransferInfo = new DataTransferInfo();
                dataTransferInfo.ExcelExportType = "Html";
                //dataTransferInfo.ExcelExportType = "OleDB";
                dataTransferInfo.DataTable = null;
                dataTransferInfo.DestinationExcelFilePath = @"D:\\test\\blank.html";
                //dataTransferInfo.DestinationExcelFilePath = @"D:\Lab\POCs\Security\TestExcelOne.xlsx";
                //dataTransferInfo.ExcelSheetName = "TestSheetName";

                DataTransferFactory dataTransferFactory = new DataTransferFactory();
                var dataTransferExcel = dataTransferFactory.GetDataTransferHandler("Excel");
                dataTransferExcel.Export(dataTransferInfo);

                throw new System.Exception(dataTransferInfo.ErrorMessage.ToString());
            }
            catch (Exception ex)
            {
                Assert.AreEqual("WriteToHtmlFormatExcel :: dtExcelData is null", ex.Message);
                throw;
            }
        }

        */


        
       /* [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Withdraw_AmountMoreThanBalance_Throws()
        {
            // arrange  
            int n = 2000;
            // act 
            Program.Withdraw(n);
            // assert is handled by the ExpectedException  
        }  */
/*
         [TestMethod]
         [ExpectedException(typeof(ArgumentException))]
        public void AESEncryptsException()
        {
            CryptInfo new1 = new CryptInfo();
            new1.ValueToCrypt = "cogni";
            new1.CryptKey =null;
            AESCrypt obj1 = new AESCrypt();
            try
            {
                string result = obj1.Encrypt(new1);
            }
             catch
            {
                 //Assert.AreEqual("Invalid TamperProofString",ex.Message);
                 throw;
            }

        }
        */

    }
}
