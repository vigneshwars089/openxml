﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Configuration
{
    public class ConfigurationFactory :IConfigurationFactory
    {
        public ICustomConfiguration GetConfigurationHandler(string configurationType)
        {
            switch (configurationType)
            {
                case S_ConfigurationType.DynamicField:
                    return new DynamicFieldsConfiguration();
                case S_ConfigurationType.ApplicationSettings:
                    return new ApplicationSettingsConfiguration();
                case S_ConfigurationType.AuditSettings:
                    return new AuditSettingsConfiguration();
                case S_ConfigurationType.ProductionSettings:
                    return new ProductionSettingsConfiguration();
                default:
                    return null;
            }
        }
    }
}
