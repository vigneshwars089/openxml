﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Entities
{      
     [Serializable]
    public class RoleInfo : BaseInfo
    {
     
        public int RoleId { set; get; }
      
      
    }

     public class UserRoleInfo : BaseInfo
     {
         public string UserRoleMapId { get; set; }
         public List<RoleInfo> UserRoles { get; set; }
         public UserInfo User { get; set; }
     }
}
