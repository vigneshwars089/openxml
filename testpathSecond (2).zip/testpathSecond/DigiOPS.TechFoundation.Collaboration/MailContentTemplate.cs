﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DigiOPS.TechFoundation.Collaboration
{
   public class MailContentTemplate : BaseContentTemplate
    {
       public override string GetTemplate(EMailInfo objInfo)
       {
          string szBodyContent = string.Empty;
            try
            {
                using (StreamReader reader = new StreamReader(HttpContext.Current.Server.MapPath(objInfo.szPath) + "\\" + objInfo.szMailBodyFileName))
                {
                    if (reader != null)
                    {
                        szBodyContent = reader.ReadToEnd();
                    }
                }

                if (!string.IsNullOrWhiteSpace(szBodyContent))
                {
                    if (objInfo.MailMergeContentList != null)
                    {
                        foreach (var rplcmailContentList in objInfo.MailMergeContentList)
                        {
                            if (!string.IsNullOrWhiteSpace(rplcmailContentList.szReplaceName))
                                szBodyContent = szBodyContent.Replace(rplcmailContentList.szReplaceName, rplcmailContentList.szReplaceValue);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
            }

            return szBodyContent;
        
       }
    }
}
