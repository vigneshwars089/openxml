﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DigiOPS.TechFoundation.Logging
{
    public class LoggingFactory : ILoggingFactory
    {
        
        public ICustomLogger GetLoggingHandler(string loggerType)
        {
            switch (loggerType)
            {
                case S_LoggerTypes.Log4net:
                    return new Log4NetLogger();
           
                default:
                    return null;
            }
        }
    }
}
