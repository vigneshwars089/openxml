﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.RuleEngine
{
   public class PasswordValidation
    {
       public static bool Validation(string password)
       {
           Regex regex = new Regex(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,50}$");
           //Password must be 8-15 characters including 1 uppercase letter, 1 special character, alphanumeric characters
           Match match = regex.Match(password);
           return match.Success;
          

       }
    }
}
