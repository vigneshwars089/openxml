﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Configuration
{
    public interface ICustomConfiguration
    {
        void ReadConfiguration(ConfigurationInfo fieldconfig, ref List<DataElementEntity> DataElements);
         void WriteConfiguration(ConfigurationInfo fieldconfig, ref string value);
    }
}
