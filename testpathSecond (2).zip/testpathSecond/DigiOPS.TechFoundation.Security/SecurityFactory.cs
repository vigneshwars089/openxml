﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class SecurityFactory : ISecurityFactory
    {

        public IUserSecurity GetUserSecurityHandler(string sourceType)
        {
            switch (sourceType)
            {
                case S_SourceTypes.DB:
                    return new DBUserSecurity();
                case S_SourceTypes.AD:
                    return new ADUserSecurity();
                default:
                    return new BaseUserSecurity();
            }
        }

        public ICrypt GetCryptHandler(string cryptType)
        {
            switch (cryptType)
            {
                case S_CryptTypes.AES:
                    return new AESCrypt();
                case S_CryptTypes.RSA:
                    return new RSACrypt();
                case S_CryptTypes.Base64:
                    return new Base64Crypt();
                default:
                    return null;
            }
        }
        public IProductLicenseKey GetLicenseKeyHandler()
        {
            return new ProductLicenseKey();
        }
    }
}
