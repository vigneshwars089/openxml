﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.ExceptionHandling
{
    class QuartException :BaseException
    {
        /// <summary>
        /// System Exception that is thrown 
        /// </summary>
        private Exception innerException;
        /// <summary>
        /// Custom Message 
        /// </summary>
        private string customMessage;
        /// <summary>
        /// Public accessor of customMessage
        /// </summary>
        public string CustomMessage
        {
            get { return this.customMessage; }
            set { this.customMessage = value; }
        }
        /// <summary>
        /// Custom Exception Constructor
        /// </summary>
        public QuartException()
        {

        }

        /// <summary>
        /// Custom Exception Constructor with message
        /// </summary>
        /// <param name="message">string</param>
        public QuartException(string message)
            : base(message)
        {
            this.customMessage = message;
        }

        /// <summary>
        /// Custom Exception Constructor with message and inner exception
        /// </summary>
        /// <param name="message">string</param>
        /// <param name="inner">Exception</param>
        public QuartException(string message, Exception inner)  : base(message, inner)
        {
            this.customMessage = message;
            this.innerException = inner;
        }
    }
}
