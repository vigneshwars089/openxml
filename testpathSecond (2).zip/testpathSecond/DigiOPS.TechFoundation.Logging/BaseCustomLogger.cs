﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using DigiOPS.TechFoundation.Entities;
using System.Security;
using System.Threading;
using System.Security.Principal;
using System.Reflection;

namespace DigiOPS.TechFoundation.Logging
{
    public abstract class BaseCustomLogger : ICustomLogger
    {
        public virtual void LogInfo(LogInfo loginfo)
        {
           
        }
        public virtual void LogException(Exception ex)
        {
           
        }
        public virtual void LogException(Exception ex, string category, string loglistenertype)
        { }

        public virtual void LogDebug(object logdebug)
        {
           
        }

        public virtual void LogDebug(object logdebug, Exception ex)
        {
           
        }
        #region Helper Method
        private  Dictionary<string, string> PopulateEnvironmentInformation(ref Dictionary<string, string> additionalInformation)
        {

            const string SOURCE_NAME = "SimpleLogger";

            if ((additionalInformation == null))
            {
                additionalInformation = new Dictionary<string, string>();
            }
            //Adding Machine Name
            try
            {
                //  if (Environment.GetLogicalDrives()
                additionalInformation.Add((SOURCE_NAME + ".MachineName"), Environment.MachineName);
            }
            catch (SecurityException novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".MachineName"), "Insufficient permissions to access information." + novar.Message);
            }
            catch (Exception novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".MachineName"), "Error accessing information. " + novar.Message);
            }
            //Adding Time Stamp
            try
            {
                additionalInformation.Add((SOURCE_NAME + ".TimeStamp"), DateTime.Now.ToString());
            }
            catch (SecurityException novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".TimeStamp"), "Insufficient permissions to access information." + novar.Message);
            }
            catch (Exception novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".TimeStamp"), "Error accessing information. " + novar.Message);
            }
            //Adding Executing Assembly Full Name
            try
            {
                additionalInformation.Add((SOURCE_NAME + ".FullName"), Assembly.GetExecutingAssembly().FullName);
            }
            catch (SecurityException novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".FullName"), "Insufficient permissions to access information." + novar.Message);
            }
            catch (Exception novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".FullName"), "Error accessing information." + novar.Message);
            }
            //Adding App Domain Name
            try
            {
                additionalInformation.Add((SOURCE_NAME + ".AppDomainName"), AppDomain.CurrentDomain.FriendlyName);
            }
            catch (SecurityException novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".AppDomainName"), "Insufficient permissions to access information." + novar.Message);
            }
            catch (Exception novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".AppDomainName"), "Error accessing information. " + novar.Message);
            }
            //Adding Thread Identity
            try
            {
                additionalInformation.Add((SOURCE_NAME + ".ThreadIdentity"), Thread.CurrentPrincipal.Identity.Name);
            }
            catch (SecurityException novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".ThreadIdentity"), "Insufficient permissions to access information. " + novar.Message);
            }
            catch (Exception novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".ThreadIdentity"), "Error accessing information. " + novar.Message);
            }
            //Adding the current Windows Identity(logged on user)
            try
            {
                additionalInformation.Add((SOURCE_NAME + ".WindowsIdentity"), WindowsIdentity.GetCurrent().Name);
            }
            catch (SecurityException novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".WindowsIdentity"), "Insufficient permissions to access information. " + novar.Message);
            }
            catch (Exception novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".WindowsIdentity"), "Error accessing information. " + novar.Message);
            }
            //Adding the OS version
            try
            {
                additionalInformation.Add((SOURCE_NAME + ".OSVersion"), Environment.OSVersion.ToString());
            }
            catch (SecurityException novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".OSVersion"), "Insufficient permissions to access information. " + novar.Message);
            }
            catch (Exception novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".OSVersion"), "Error accessing information." + novar.Message);
            }
            //Adding the CLR Version
            try
            {
                additionalInformation.Add((SOURCE_NAME + ".CLRVersion"), Environment.Version.ToString());
            }
            catch (SecurityException novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".CLRVersion"), "Insufficient permissions to access information" + novar.PermissionType.Name);
            }
            catch (Exception novar)
            {
                additionalInformation.Add((SOURCE_NAME + ".CLRVersion"), "Error accessing information" + novar.Message);
            }
            //Return the populated Dictionary object
            return additionalInformation;
        }
       
        
        #region  StringBuilder SerializeToText
        /// <summary>
        /// Serializes the exception tree into text		
        /// <param name="exception">Exception to be serialized</param>
        /// <param name="additionalInformation">Additional information associated with the exception</param>
        /// <returns>StringBuilder - Text Serialized form of the exception tree</returns>
        /// </summary>
        internal  StringBuilder SerializeToText(Exception ex, ref Dictionary<string, string> additionalInformation)
        {
            try
            {


                const string TEXT_SEPERATOR = "----------------------------------------------------";

                //Build the Additional Params String
                StringBuilder sbExceptionMessageTemplate = new StringBuilder();

                if (!(additionalInformation == null))
                {

                    // //Adding the header
                    sbExceptionMessageTemplate.AppendFormat("{0}Exception Log Generated On {2} at {3}{0}{1}{0}General Information{0}{4}", Environment.NewLine, TEXT_SEPERATOR, DateTime.Now.ToLongDateString(), DateTime.Now.ToLongTimeString(), TEXT_SEPERATOR);


                    //Adding all the Additional Parameters
                    foreach (String strParam in (PopulateEnvironmentInformation(ref additionalInformation)).Keys)
                    {
                        sbExceptionMessageTemplate.AppendFormat("{0}{1}: {2}", Environment.NewLine, strParam, additionalInformation[strParam]);
                    }
                }
                if ((ex == null))
                {
                    sbExceptionMessageTemplate.AppendFormat("{0}{0}No Exception Information Exists{0}", Environment.NewLine);
                }
                else
                {
                    //Extract the details for the entire exception tree
                    Dictionary<string, string> customAdditionalInfo;
                    Exception currentException = ex;
                    Int32 intExceptionCount = 1;
                    while (!(currentException == null))
                    {
                        sbExceptionMessageTemplate.AppendFormat("{0}{0}Exception Information: Exception #{1}{0}{2}", Environment.NewLine, intExceptionCount.ToString(), TEXT_SEPERATOR);

                        sbExceptionMessageTemplate.AppendFormat("{0}Exception Type: {1}", Environment.NewLine, currentException.GetType().FullName);


                        //Getting the properties of the current exception
                        foreach (PropertyInfo pInfo in currentException.GetType().GetProperties())
                        {
                            //StackTrace and Innerexception are treated seperately
                            if (((pInfo.Name != "StackTrace") && (pInfo.Name != "InnerException")))
                            {
                                //Check for NULL property Values
                                if ((pInfo.GetValue(currentException, null) == null))
                                {
                                    sbExceptionMessageTemplate.AppendFormat("{0}{1}: NULL/Undefined", Environment.NewLine, pInfo.Name);
                                }
                                else
                                {
                                    //Get the associated Additional Information if the Exception is of Type ApplicationExceptionBase
                                    if (pInfo.Name == "AdditionalInformation")
                                    {
                                        if (!(pInfo.GetValue(currentException, null) == null))
                                        {
                                            customAdditionalInfo = ((Dictionary<string, string>)(pInfo.GetValue(currentException, null)));

                                            if ((customAdditionalInfo.Count > 0))
                                            {
                                                sbExceptionMessageTemplate.AppendFormat("{0}Additional Exception Information:", Environment.NewLine);

                                                foreach (String lstrParam in customAdditionalInfo.Keys)
                                                {
                                                    sbExceptionMessageTemplate.AppendFormat("{0}  {1}: {2}", Environment.NewLine, lstrParam, customAdditionalInfo[lstrParam]);
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        sbExceptionMessageTemplate.AppendFormat("{0}{1}: {2}", Environment.NewLine, pInfo.Name, pInfo.GetValue(currentException, null));
                                    }
                                }
                            }
                        }
                        // //Writing out the Stack Trace Information
                        if (!(currentException.StackTrace == null))
                        {
                            sbExceptionMessageTemplate.AppendFormat("{0}{0}Stack Trace Information{0}{1}", Environment.NewLine, TEXT_SEPERATOR);
                            sbExceptionMessageTemplate.AppendFormat("{0}{1}", Environment.NewLine, currentException.StackTrace);
                        }
                        // //Get the Inner Exception
                        currentException = currentException.InnerException;
                        intExceptionCount++;
                    }
                }
                return sbExceptionMessageTemplate;
            }
            catch (Exception lserException)
            {

                throw new Exception("Error serializing  exception to text", lserException);
            }
        }
        #endregion

     

        #endregion

      
    }
}
