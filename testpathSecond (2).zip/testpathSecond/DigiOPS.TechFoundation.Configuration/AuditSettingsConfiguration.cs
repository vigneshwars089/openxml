﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Configuration;
using System.Xml.Linq;
using DigiOPS.TechFoundation.Logging;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using DigiOPS.TechFoundation.DataAccessLayer;
using Microsoft.Practices.EnterpriseLibrary.Data;
using DigiOPS.TechFoundation.ExceptionHandling;


using System.IO;
using System.Windows.Input;

using System.Text.RegularExpressions;


//using EMTWebApp;


using System.Net.Mail;

using System.Net;

using System.Globalization;

namespace DigiOPS.TechFoundation.Configuration
{
    public class AuditSettingsConfiguration : BaseCustomConfiguration
    {
        DataTable dt = null;
        List<ConfigurationInfo> baseList = null;
        Log4NetLogger proxyLogger = new Log4NetLogger();
        public Database Db = DatabaseFactory.CreateDatabase("ConnStr");
        public override void ReadConfiguration(ConfigurationInfo fieldconfig, ref List<DataElementEntity> DataElements)
        {
            string EntityName = fieldconfig.GetType().Name;
            Log4NetLogger proxyLogger = new Log4NetLogger();
            try
            {
                switch (fieldconfig.AppID)
                {

                    case S_AppID.QUART:

                        

                       

                        //WorkflowAuditConfigDAO waDAOAuditConfig = new WorkflowAuditConfigDAO();
                        //WorkflowAuditConfigMapper objworkflowmapAuditConfig = new WorkflowAuditConfigMapper();
                        try
                        {

                            dt = GetEntityRecordByEntity(fieldconfig);
                            //if (dt.Rows.Count <= 0)

                            baseList = MapToWorkflowAuditConfigList(dt);

                        }
                        catch (InvalidCastException Ex)
                        {
                            proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                        }
                        catch (Exception Ex)//QuartException
                        {
                            proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                        }
                        finally
                        {
                            // waDAOAuditConfig = null;
                            //objworkflowmapAuditConfig = null;
                        }
                        break;
                    default:
                        proxyLogger.Log.Info("Default value matched in Get entity " + EntityName);
                        break;
                }
            }
            catch (InvalidCastException Ex)
            {
                proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)//QuartException
            {
                proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
            }
            finally
            {
                //if (ds != null) ds.Dispose();
                if (dt != null) dt.Dispose();
            }
            proxyLogger.Log.Info(EntityName + " - Called.");
            //return baseList;
            ArrayList baseListArray = new ArrayList();
            baseListArray.Add(baseList);

            //AuditElements = baseListArray;
        }

        public override void WriteConfiguration(ConfigurationInfo fieldconfig,ref string value)
        {
            string createRecVal = string.Empty;

            string EntityName = fieldconfig.GetType().Name;
            try
            {
                switch (fieldconfig.AppID)
                {
                    case S_AppID.QUART:
                        {

                            // WorkflowAuditConfigDAO waDAO = new WorkflowAuditConfigDAO();
                            try
                            {
                                createRecVal = SetWorkflowAuditConfiguration((ConfigurationEntity)fieldconfig);
                            }
                            catch (InvalidCastException Ex)
                            {
                                proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                            }
                            catch (Exception Ex)//QuartException
                            {
                                proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
                            }
                            finally
                            {
                                //waDAO = null;
                            }
                            break;

                        }
                    default:
                        proxyLogger.Log.Info("Default value matched in set Entity  " + EntityName);
                        break;

                }

            }

            catch (InvalidCastException Ex)
            {
                proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
            }
            catch (Exception Ex)//QuartException
            {
                proxyLogger.Log.Error(Ex.Message); proxyLogger.Log.Error(Ex.StackTrace);
            }

            proxyLogger.Log.Info(EntityName + " - Called.");
            value = createRecVal;
        }







        public string SetWorkflowAuditConfiguration(ConfigurationEntity objConfigEntity)//----to set the audit and workflow configuration
        {
            Log4NetLogger proxyLogger = new Log4NetLogger();
            string resultValue = "-1";
            try
            {
               
                XElement Parent = new XElement("root");//to show the grids in the UI
                XElement root = new XElement("xmlArguments");


                const string ACTION_Insert = "INSERT";//constant procedures
                const string ACTION_Update = "UPDATE";
                using (SqlConnection sqlConnection = new SqlConnection(Db.ConnectionString))
                {
                    sqlConnection.Open();
                    SqlCommand command = new SqlCommand("USP_SET_WORKFLOW_AUDIT_CONFIG", sqlConnection);
                    command.CommandType = CommandType.StoredProcedure;

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.WorkflowConfigID)))
                        root.Add(new XAttribute("iWorkflowConfigurationID", Convert.ToString(objConfigEntity.WorkflowConfigID)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.AuditConfigId)))
                        root.Add(new XAttribute("iAuditConfigurationID", Convert.ToString(objConfigEntity.AuditConfigId)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity._SubProcessID)))
                        root.Add(new XAttribute("iSubProcessID", Convert.ToString(objConfigEntity._SubProcessID)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.TransactionTypeID)))
                        root.Add(new XAttribute("byTransactionTypeID", Convert.ToString(objConfigEntity.TransactionTypeID)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.iSubCategoryId)))
                        root.Add(new XAttribute("iSubCategoryID", Convert.ToString(objConfigEntity.iSubCategoryId)));


                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsCoreTransactionStatusRequired)))
                        root.Add(new XAttribute("bIsCoreTransactionStatusRequired", Convert.ToString(objConfigEntity.IsCoreTransactionStatusRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsCoreTransactionStatusReasonRequired)))
                        root.Add(new XAttribute("bIsCoreTransactionStatusReasonRequired", Convert.ToString(objConfigEntity.IsCoreTransactionStatusReasonRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsSuperVisorAuditRequired)))
                        root.Add(new XAttribute("bIsSupervisorRequired", Convert.ToString(objConfigEntity.IsSuperVisorAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsInternalExternalAuditRequired)))
                        root.Add(new XAttribute("bIsInternalExternalAuditRequired", Convert.ToString(objConfigEntity.IsInternalExternalAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsExternalAuditRequired)))
                        root.Add(new XAttribute("bIsExternalAuditRequired", Convert.ToString(objConfigEntity.IsExternalAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.szSamplingMethodInternal)))
                        root.Add(new XAttribute("szSamplingMethodInternal", Convert.ToString(objConfigEntity.szSamplingMethodInternal)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.szSamplingMethodBusiness)))
                        root.Add(new XAttribute("szSamplingMethodBusiness", Convert.ToString(objConfigEntity.szSamplingMethodBusiness)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.isBusiAutoAllocationSamplingRequired)))
                        root.Add(new XAttribute("isBusiAutoAllocationSamplingRequired", Convert.ToString(objConfigEntity.isBusiAutoAllocationSamplingRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.isExternalAutoAllocationSamplingRequired)))
                        root.Add(new XAttribute("isExternalAutoAllocationSamplingRequired", Convert.ToString(objConfigEntity.isExternalAutoAllocationSamplingRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsDirectBusinessAuditRequired)))
                        root.Add(new XAttribute("bIsDirectBusinessAuditRequired", Convert.ToString(objConfigEntity.IsDirectBusinessAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsTotalVolumeAuditRequired)))
                        root.Add(new XAttribute("bIsTotalAuditRequired", Convert.ToString(objConfigEntity.IsTotalVolumeAuditRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.AuditingLogicType)))
                        root.Add(new XAttribute("szAuditingLogicType", Convert.ToString(objConfigEntity.AuditingLogicType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ScoringLogicType)))
                        root.Add(new XAttribute("szScoringLogicType", Convert.ToString(objConfigEntity.ScoringLogicType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsEmpNeeded)))
                        root.Add(new XAttribute("bIsEmpNeeded", Convert.ToString(objConfigEntity.IsEmpNeeded)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.bIsLineApplicable)))
                        root.Add(new XAttribute("bIsLineApplicable", Convert.ToString(objConfigEntity.bIsLineApplicable)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.bIsExternalAudit)))
                        root.Add(new XAttribute("bIsExternalAudit", Convert.ToString(objConfigEntity.bIsExternalAudit)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.SubDefectLevel)))
                        root.Add(new XAttribute("bySubDefectLevel", Convert.ToString(objConfigEntity.SubDefectLevel)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.SamplingType)))
                        root.Add(new XAttribute("szSamplingType", Convert.ToString(objConfigEntity.SamplingType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ExternalSamplingType)))
                        root.Add(new XAttribute("szExternalSamplingType", Convert.ToString(objConfigEntity.ExternalSamplingType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.BusinessSamplingType)))
                        root.Add(new XAttribute("szBusinessSamplingType", Convert.ToString(objConfigEntity.BusinessSamplingType)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ReworkRequiredFor)))
                        root.Add(new XAttribute("szRework_MandatoryFor", Convert.ToString(objConfigEntity.ReworkRequiredFor)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ReworkupdateNeedFor)))
                        root.Add(new XAttribute("szRework_Update_NeededFor", Convert.ToString(objConfigEntity.ReworkupdateNeedFor)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.ManualAllocationRequiredFor)))
                        root.Add(new XAttribute("szManualAllo_NeededFor", Convert.ToString(objConfigEntity.ManualAllocationRequiredFor)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsAutoSamplingRequired)))
                        root.Add(new XAttribute("bIsAutoSamplingNeeded", Convert.ToString(objConfigEntity.IsAutoSamplingRequired)));

                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.IsActive)))
                        root.Add(new XAttribute("bIsActive", Convert.ToInt32(objConfigEntity.IsActive)));

                    int AssociateID = 0;

                    if (objConfigEntity.Action == ACTION_Insert)
                    {
                        int.TryParse(objConfigEntity.CreatedBy.Trim(), out AssociateID);
                        root.Add(new XAttribute("iAssociateID", Convert.ToString(AssociateID)));
                    }
                    else if (objConfigEntity.Action ==ACTION_Update)
                    {
                        int.TryParse(objConfigEntity.ModifiedBy.Trim(), out AssociateID);
                        root.Add(new XAttribute("iAssociateID", Convert.ToString(AssociateID)));
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(objConfigEntity.Action)))
                        root.Add(new XAttribute("szOpertaionName", Convert.ToString(objConfigEntity.Action)));

                    Parent.Add(root);

                    command.Parameters.Add("@ExcelData", SqlDbType.Xml).Value = Convert.ToString(Parent);
                    command.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                    command.ExecuteNonQuery();
                    resultValue = command.Parameters["@RETURN_VALUE"].Value.ToString();
                }

               
            }
            catch (ArgumentException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (Exception ex)//QuartException
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                //throw new QuartException(ex.Message, ex.InnerException);
            }
            return resultValue;
        }


        public DataTable GetEntityRecordByEntity(ConfigurationInfo objBaseEntity)//--- to get the entity audit workflow record---quart
        {
            DataSet _ds = new DataSet();
            DataTable dt = new DataTable();
            try
            {
                //DataTable _dt = new DataTable();
                
                using (SqlConnection SqlConnection = new SqlConnection(Db.ConnectionString))
                {
                    SqlConnection.Open();
                    SqlCommand command = new SqlCommand("usp_Get_Workflow_Audit_Configuration_By_SubProcessID", SqlConnection);
                    command.Parameters.Add("@iSubProcessID", SqlDbType.Int).Value = objBaseEntity._SubProcessID;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    adp.Fill(_ds);
                }
               
            }
            catch (ArgumentException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (SqlException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (ApplicationException ex)
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
                throw;
            }
            catch (Exception ex)//QuartException
            {
                proxyLogger.Log.Error(ex.Message); proxyLogger.Log.Error(ex.StackTrace);
             //   throw new QuartException(ex.Message, ex.InnerException);
            }
            return (_ds.Tables[0]);
        }



        internal List<ConfigurationInfo> MapToWorkflowAuditConfigList(DataTable dt)//to map the elements got using GetEntityRecordByEntity---quart
        {
            List<ConfigurationInfo> baseEntityList = new List<ConfigurationInfo>();



            baseEntityList = (from p in dt.AsEnumerable()
                              select new ConfigurationEntity
                              {
                                  WorkflowConfigID = Convert.ToInt32(p["iWorkflowConfigId"] == DBNull.Value ? 0 : p["iWorkflowConfigId"]),
                                  TransactionTypeID = Convert.ToInt16(p["byTransactionTypeId"] == DBNull.Value ? 0 : p["byTransactionTypeId"]),
                                  iSubCategoryId = Convert.ToInt16(p["iSubcategoryId"] == DBNull.Value ? 0 : p["iSubcategoryId"]),
                                  IsCoreTransactionStatusRequired = Convert.ToBoolean(p["bIsCoreTransStatusApplicable"] == DBNull.Value ? 0 : p["bIsCoreTransStatusApplicable"]),
                                  IsCoreTransactionStatusReasonRequired = Convert.ToBoolean(p["bIsCoreTransStatusReasonApplicable"] == DBNull.Value ? 0 : p["bIsCoreTransStatusReasonApplicable"]),

                                  IsInternalExternalAuditRequired = Convert.ToBoolean(p["bIsInternalExternalAuditRequired"] == DBNull.Value ? 0 : p["bIsInternalExternalAuditRequired"]),
                                  IsDirectBusinessAuditRequired = Convert.ToBoolean(p["bIsBusinessAuditRequired"] == DBNull.Value ? 0 : p["bIsBusinessAuditRequired"]),
                                  IsSuperVisorAuditRequired = Convert.ToBoolean(p["bIsSupervisorRequired"] == DBNull.Value ? 0 : p["bIsSupervisorRequired"]),
                                  IsExternalAuditRequired = Convert.ToBoolean(p["bIsExternalAuditRequired"] == DBNull.Value ? 0 : p["bIsExternalAuditRequired"]),

                                  IsTotalVolumeAuditRequired = Convert.ToBoolean(p["bIsTotalVolumeRequired"] == DBNull.Value ? 0 : p["bIsTotalVolumeRequired"]),
                                  IsAutoSamplingRequired = Convert.ToBoolean(p["bIsAutoSamplingNeeded"] == DBNull.Value ? 0 : p["bIsAutoSamplingNeeded"]),
                                  _SubProcessID = Convert.ToInt32(p["iSubProcessId"] == DBNull.Value ? 0 : p["iSubProcessId"]),
                                  SubProcessID = Convert.ToInt32(p["iSubProcessId"] == DBNull.Value ? 0 : p["iSubProcessId"]),

                                  AuditConfigId = Convert.ToInt32(p["iAuditConfigId"] == DBNull.Value ? 0 : p["iAuditConfigId"]),
                                  AuditingLogicType = Convert.ToString(p["szAuditingLogicType"] == DBNull.Value ? 0 : p["szAuditingLogicType"]),
                                  ScoringLogicType = Convert.ToString(p["szScoringLogicType"] == DBNull.Value ? 0 : p["szScoringLogicType"]),
                                  IsEmpNeeded = Convert.ToBoolean(p["bIsEmpNeeded"] == DBNull.Value ? 0 : p["bIsEmpNeeded"]),
                                  bIsLineApplicable = Convert.ToBoolean(p["bIsLineNeeded"] == DBNull.Value ? 0 : p["bIsLineNeeded"]),
                                  bIsExternalAudit = Convert.ToBoolean(p["bIsExternalAudit"] == DBNull.Value ? 0 : p["bIsExternalAudit"]),
                                  SubDefectLevel = Convert.ToInt16(p["bySubDefectLevel"] == DBNull.Value ? 0 : p["bySubDefectLevel"]),
                                  SamplingType = Convert.ToString(p["szSamplingType"] == DBNull.Value ? 0 : p["szSamplingType"]),
                                  ExternalSamplingType = Convert.ToString(p["szExternalSamplingType"] == DBNull.Value ? 0 : p["szExternalSamplingType"]),
                                  BusinessSamplingType = Convert.ToString(p["szBusinessSamplingType"] == DBNull.Value ? 0 : p["szBusinessSamplingType"]),
                                  isBusiAutoAllocationSamplingRequired = Convert.ToBoolean(p["bIsBusiAutoSamplingNeeded"] == DBNull.Value ? 0 : p["bIsBusiAutoSamplingNeeded"]),
                                  isExternalAutoAllocationSamplingRequired = Convert.ToBoolean(p["bIsExternalAutoSamplingNeeded"] == DBNull.Value ? 0 : p["bIsExternalAutoSamplingNeeded"]),
                                  ReworkRequiredFor = Convert.ToString(p["szRework_Update_NeededFor"] == DBNull.Value ? string.Empty : p["szRework_Update_NeededFor"]),
                                  ReworkupdateNeedFor = Convert.ToString(p["szRework_MandatoryFor"] == DBNull.Value ? string.Empty : p["szRework_MandatoryFor"]),
                                  ManualAllocationRequiredFor = Convert.ToString(p["szManualAllo_NeededFor"] == DBNull.Value ? string.Empty : p["szManualAllo_NeededFor"]),

                                  CreatedBy = Convert.ToString(p["iCreatedBy"] == DBNull.Value ? "0" : p["iCreatedBy"]).ToString(),
                                  CreatedDate = Convert.ToDateTime(p["dsCreatedDate"] == DBNull.Value ? 0 : p["dsCreatedDate"]).ToString(),

                                  ModifiedBy = Convert.ToString(p["iModifiedBy"] == DBNull.Value ? "0" : p["iModifiedBy"]).ToString(),
                                  ModifiedDate = Convert.ToDateTime(p["dsModifiedDate"] == DBNull.Value ? 0 : p["dsModifiedDate"]).ToString(),

                                  IsEditAllowed = Convert.ToBoolean(p["bIsEditAllowed"] == DBNull.Value ? 0 : p["bIsEditAllowed"]),
                                  szSamplingMethodInternal = Convert.ToString(p["szSamplingMethodInternal"] == DBNull.Value ? string.Empty : p["szSamplingMethodInternal"]),
                                  szSamplingMethodBusiness = Convert.ToString(p["szSamplingMethodBusiness"] == DBNull.Value ? string.Empty : p["szSamplingMethodBusiness"])

                              }).Cast<ConfigurationInfo>().ToList();

            return baseEntityList;

        }



    }
}
