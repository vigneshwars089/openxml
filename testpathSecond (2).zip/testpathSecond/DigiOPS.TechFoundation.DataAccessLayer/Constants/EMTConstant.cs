﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
    public static class EMTConstant
    {
        public struct S_UserDBScripts
        {
            public const string CREATE_USERS = "USP_CREATE_USERS";
            public const string UPDATE_USERS = "USP_UPDATE_USERS";
            public const string RSA = "RSA";
            public const string Base64 = "Base64";
        }
        public struct S_RoleDBScripts
        {
            public const string CreateRoleMap = "USP_USER_ROLEMAP";
            public const string UpdateRoleMap = "USP_UPDATE_ROLEMAPPED_USERS";
            public const string DeleteRoleMap = "USP_DELETE_ROLEMAPPED_USERS";
        }

    }
}
