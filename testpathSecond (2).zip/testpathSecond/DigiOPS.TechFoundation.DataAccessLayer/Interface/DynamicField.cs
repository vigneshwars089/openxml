﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using DigiOPS.TechFoundation.Entities;

namespace DigiOPS.TechFoundation.DataAccessLayer
{
   public interface DynamicField
    {
            DataTable GetDataElementRecordList(ConfigurationInfo DataElementEnt);//to read the list of elements from quart db
            string CUDDataElementRecord(ConfigurationInfo DataElementEnt);//to write the fields for quart

    }
}
