﻿using DigiOPS.TechFoundation.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class CryptInfo : BaseInfo
    {
        public string ValueToCrypt { set; get; }
        public string CryptKey { set; get; }
    }
}
