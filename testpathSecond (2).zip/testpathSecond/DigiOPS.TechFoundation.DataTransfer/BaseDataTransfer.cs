﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.DataTransfer
{
   public abstract class BaseDataTransfer : ICustomDataTransfer
    {
        public virtual void Import(DataTransferInfo dataTransferinfo)
        {
           
        }


        public virtual void Export(DataTransferInfo dataTransferinfo)
        {
            
        }

        
    }
}
