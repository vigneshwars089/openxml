﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace DigiOPS.TechFoundation.Logging
{
    public class Log4NetLogger : BaseCustomLogger
    {

        public ILog log = null;

        public ILog Log
        {
            get
            {
                if (log == null)
                {
                    log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
                }
                return log;
            }
        }
        public override void LogInfo(LogInfo loginfo)
        {
            Log.Info(loginfo.ErrorMessage);
        }

        public override void LogException(Exception ex)
        {
            Log.Error(ex.StackTrace, ex);
        }
        public override void LogException(Exception ex, string category, string loglistenertype)
        {
             Dictionary<string, string> additionalInfo = new Dictionary<string, string>();
            string msg=(SerializeToText(ex, ref additionalInfo)).ToString();
            Log.Error(msg, ex);
        }

        public override void LogDebug(object logdebug)
        {
            Log.Debug(logdebug);
        }

        public override void LogDebug(Object logdebug,Exception ex)
        {
            Log.Debug(logdebug, ex);
        }
       


    }

}