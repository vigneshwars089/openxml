﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
    public class DBSecurityHandler : BaseUserSecurity
    {
        //public override bool DBSecurityHandlerAuthorize(UserContextInfo objUserContextInfo)
        //{
        //    Hashtable hs = new Hashtable();
        //    hs.Add("@UserID", objUserContextInfo.UserID.Trim());
        //    if (!string.IsNullOrEmpty(objUserContextInfo.Password.Trim()))
        //        hs.Add("@Password", objUserContextInfo.Password.Trim());
        //    else
        //    {
        //        //string conn=ConfigurationManager[""];
        //     //   return Convert.ToInt32(this.SelectSingleValue("USP_USERLOGIN", hs));
        //    }
        //    //to your logic here
        //    return false;
        //}
    }
}
