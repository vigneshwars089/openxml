﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiOPS.TechFoundation.Security
{
   public static class ErrorMessage
    {
        static ErrorMessage() { }
       public static string ERR_REQ_Username = "Enter the Username";
        public const string ERR_REQ_Password = "Enter the Password";
        public const string ERR_REQ_EncryptConfirmPassword = "Enter the Confirmed Password";
        public const string ERR_REQ_EncryptPassword = "Enter the New Password"; 
    }
}
